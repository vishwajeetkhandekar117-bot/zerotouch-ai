package com.zerotouch.ai.ui

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zerotouch.ai.data.local.CommandHistoryEntity
import com.zerotouch.ai.data.model.OpenRouterResult
import com.zerotouch.ai.data.remote.OpenRouterRepository
import com.zerotouch.ai.service.FloatingOverlayService
import com.zerotouch.ai.service.VoiceCommandService
import com.zerotouch.ai.service.ZeroTouchAccessibilityService
import com.zerotouch.ai.util.Constants
import com.zerotouch.ai.util.PermissionHelper
import com.zerotouch.ai.util.SecurityUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class UiState(
    val commandText: String = "",
    val isLoading: Boolean = false,
    val isListening: Boolean = false,
    val lastResult: String? = null,
    val hasError: Boolean = false,
    val status: String = "Ready",
    val apiKey: String = "",
    val selectedModel: String = Constants.AVAILABLE_MODELS[0],
    val ttsEnabled: Boolean = true,
    val confirmationRequired: Boolean = false,
    val overlayEnabled: Boolean = false,
    val isAccessibilityEnabled: Boolean = false,
    val isOverlayGranted: Boolean = false,
    val isMicGranted: Boolean = false,
    val commandCount: Int = 0,
    val totalTokens: Int = 0
)

@HiltViewModel
class MainViewModel @Inject constructor(
    private val repository: OpenRouterRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState

    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history

    private var voiceService: VoiceCommandService? = null
    private var executeJob: Job? = null

    fun init(context: Context) {
        val apiKey = SecurityUtils.getApiKey(context)
        val prefs = context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        val model = prefs.getString(Constants.KEY_SELECTED_MODEL, Constants.AVAILABLE_MODELS[0])!!
        val tts = prefs.getBoolean(Constants.KEY_TTS_ENABLED, true)
        val confirm = prefs.getBoolean(Constants.KEY_CONFIRMATION_REQUIRED, false)
        val overlay = prefs.getBoolean(Constants.KEY_OVERLAY_ENABLED, false)

        _uiState.update {
            it.copy(
                apiKey = apiKey,
                selectedModel = model,
                ttsEnabled = tts,
                confirmationRequired = confirm,
                overlayEnabled = overlay,
                isAccessibilityEnabled = PermissionHelper.isAccessibilityEnabled(context),
                isOverlayGranted = PermissionHelper.isOverlayPermissionGranted(context),
                isMicGranted = PermissionHelper.isMicrophonePermissionGranted(context)
            )
        }
        refreshHistory()
        refreshStats()
        if (overlay && PermissionHelper.isOverlayPermissionGranted(context)) {
            startOverlayService(context)
        }
    }

    fun refreshPermissions(context: Context) {
        _uiState.update {
            it.copy(
                isAccessibilityEnabled = PermissionHelper.isAccessibilityEnabled(context),
                isOverlayGranted = PermissionHelper.isOverlayPermissionGranted(context),
                isMicGranted = PermissionHelper.isMicrophonePermissionGranted(context)
            )
        }
    }

    fun onCommandTextChanged(text: String) {
        _uiState.update { it.copy(commandText = text) }
    }

    fun executeCommand(context: Context) {
        val state = _uiState.value
        if (state.commandText.isBlank()) return
        if (state.apiKey.isBlank()) {
            _uiState.update { it.copy(lastResult = "Please set your OpenRouter API key in Settings.", hasError = true) }
            return
        }
        if (!state.isAccessibilityEnabled) {
            _uiState.update { it.copy(lastResult = "Enable the Accessibility Service first.", hasError = true) }
            return
        }

        executeJob?.cancel()
        executeJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, status = "Thinking…", lastResult = null, hasError = false) }

            // Capture current screen
            val screenContext = ZeroTouchAccessibilityService.instance?.getScreenContext()

            val result = repository.processCommand(
                userCommand = state.commandText,
                screenContext = screenContext,
                apiKey = state.apiKey,
                modelIndex = Constants.AVAILABLE_MODELS.indexOf(state.selectedModel).coerceAtLeast(0)
            )

            when (result) {
                is OpenRouterResult.Success -> {
                    val agentResponse = result.data
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            status = "Executing…",
                            lastResult = agentResponse.confirmation,
                            hasError = false,
                            commandText = ""
                        )
                    }

                    // Execute actions via accessibility engine
                    val service = ZeroTouchAccessibilityService.instance
                    if (service != null) {
                        val engine = service.createActionEngine()
                        engine.executeResponse(agentResponse)
                    }

                    if (state.ttsEnabled) {
                        voiceService?.speak(agentResponse.confirmation)
                    }

                    _uiState.update { it.copy(status = "Ready") }
                    refreshHistory()
                    refreshStats()
                }
                is OpenRouterResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            status = "Error",
                            lastResult = "Error: ${result.message}",
                            hasError = true
                        )
                    }
                    refreshHistory()
                }
                else -> {}
            }
        }
    }

    fun toggleVoiceInput(context: Context) {
        if (_uiState.value.isListening) {
            voiceService?.stopListening()
            _uiState.update { it.copy(isListening = false) }
        } else {
            if (voiceService == null) {
                voiceService = VoiceCommandService(context.applicationContext)
            }
            voiceService?.startListening { text ->
                _uiState.update { it.copy(commandText = text, isListening = false) }
            }
            _uiState.update { it.copy(isListening = true) }
        }
    }

    fun saveApiKey(context: Context, key: String) {
        SecurityUtils.saveApiKey(context, key)
        _uiState.update { it.copy(apiKey = key) }
    }

    fun setModel(context: Context, model: String) {
        context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(Constants.KEY_SELECTED_MODEL, model).apply()
        _uiState.update { it.copy(selectedModel = model) }
    }

    fun setTtsEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(Constants.KEY_TTS_ENABLED, enabled).apply()
        _uiState.update { it.copy(ttsEnabled = enabled) }
    }

    fun setConfirmationRequired(context: Context, required: Boolean) {
        context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(Constants.KEY_CONFIRMATION_REQUIRED, required).apply()
        _uiState.update { it.copy(confirmationRequired = required) }
    }

    fun setOverlayEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(Constants.KEY_OVERLAY_ENABLED, enabled).apply()
        _uiState.update { it.copy(overlayEnabled = enabled) }
        if (enabled && PermissionHelper.isOverlayPermissionGranted(context)) {
            startOverlayService(context)
        } else {
            context.stopService(Intent(context, FloatingOverlayService::class.java))
        }
    }

    private fun startOverlayService(context: Context) {
        context.startForegroundService(Intent(context, FloatingOverlayService::class.java))
    }

    fun openAccessibilitySettings(context: Context) {
        PermissionHelper.openAccessibilitySettings(context)
    }

    fun openOverlaySettings(context: Context) {
        PermissionHelper.openOverlaySettings(context)
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _history.value = emptyList()
            refreshStats()
        }
    }

    private fun refreshHistory() {
        viewModelScope.launch {
            val items = repository.getHistory().map { entity ->
                HistoryItem(
                    id = entity.id,
                    command = entity.command,
                    response = entity.response,
                    timestamp = entity.timestamp,
                    success = entity.success,
                    tokensUsed = entity.tokensUsed
                )
            }
            _history.value = items
        }
    }

    private fun refreshStats() {
        viewModelScope.launch {
            val count = repository.getHistory().count { it.success }
            val tokens = repository.getHistory().sumOf { it.tokensUsed }
            _uiState.update { it.copy(commandCount = count, totalTokens = tokens) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceService?.destroy()
    }
}
