package com.zerotouch.ai.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zerotouch.ai.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

data class HistoryItem(
    val id: Long,
    val command: String,
    val response: String,
    val timestamp: Long,
    val success: Boolean,
    val tokensUsed: Int
)

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToSettings: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val historyItems by viewModel.history.collectAsState()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    ZeroTouchTheme {
        Scaffold(
            containerColor = DarkBackground,
            topBar = {
                TopBar(
                    isServiceEnabled = uiState.isAccessibilityEnabled,
                    onSettingsClick = onNavigateToSettings
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // Permission banners
                if (!uiState.isAccessibilityEnabled) {
                    PermissionBanner(
                        icon = Icons.Filled.Accessibility,
                        message = "Accessibility service not enabled — tap to fix",
                        color = AccentYellow,
                        onClick = { viewModel.openAccessibilitySettings(context) }
                    )
                }
                if (!uiState.isOverlayGranted) {
                    PermissionBanner(
                        icon = Icons.Filled.Layers,
                        message = "Overlay permission needed for floating button",
                        color = AccentBlue,
                        onClick = { viewModel.openOverlaySettings(context) }
                    )
                }

                // Status bar
                StatusRow(
                    model = uiState.selectedModel,
                    status = uiState.status
                )

                // Command input
                CommandInput(
                    value = uiState.commandText,
                    onValueChange = viewModel::onCommandTextChanged,
                    isLoading = uiState.isLoading,
                    isListening = uiState.isListening,
                    onSend = {
                        focusManager.clearFocus()
                        viewModel.executeCommand(context)
                    },
                    onVoice = { viewModel.toggleVoiceInput(context) }
                )

                // Last result
                AnimatedVisibility(
                    visible = uiState.lastResult != null,
                    enter = fadeIn() + slideInVertically(),
                    exit = fadeOut()
                ) {
                    uiState.lastResult?.let { result ->
                        ResultCard(result = result, isError = uiState.hasError)
                    }
                }

                // History
                if (historyItems.isNotEmpty()) {
                    Text(
                        text = "Recent Commands",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = DarkOnSurface.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(historyItems) { item ->
                            HistoryCard(item = item)
                        }
                    }
                } else {
                    EmptyState()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopBar(isServiceEnabled: Boolean, onSettingsClick: () -> Unit) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(listOf(AccentBlue, AccentPurple))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    "ZeroTouch AI",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = DarkOnSurface,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isServiceEnabled) AccentGreen else AccentRed)
                )
            }
        },
        actions = {
            IconButton(onClick = onSettingsClick) {
                Icon(
                    Icons.Outlined.Settings,
                    contentDescription = "Settings",
                    tint = DarkOnSurface.copy(alpha = 0.7f)
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = DarkSurface
        )
    )
}

@Composable
private fun PermissionBanner(
    icon: ImageVector,
    message: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color.copy(alpha = 0.15f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium.copy(color = color),
            modifier = Modifier.weight(1f)
        )
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun StatusRow(model: String, status: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceVariant)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Outlined.SmartToy,
                contentDescription = null,
                tint = AccentBlue,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                model.substringAfterLast("/"),
                style = MaterialTheme.typography.labelSmall.copy(
                    color = DarkOnSurface.copy(alpha = 0.6f)
                )
            )
        }
        Text(
            status,
            style = MaterialTheme.typography.labelSmall.copy(
                color = DarkOnSurface.copy(alpha = 0.5f)
            )
        )
    }
}

@Composable
private fun CommandInput(
    value: String,
    onValueChange: (String) -> Unit,
    isLoading: Boolean,
    isListening: Boolean,
    onSend: () -> Unit,
    onVoice: () -> Unit
) {
    Surface(
        color = DarkSurface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        width = 1.dp,
                        color = if (isListening) AccentBlue else DarkOutline,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .background(DarkSurfaceVariant),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    placeholder = {
                        Text(
                            "Open WhatsApp and message Mom…",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = DarkOnSurface.copy(alpha = 0.35f)
                            )
                        )
                    },
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = DarkOnSurface,
                        unfocusedTextColor = DarkOnSurface,
                        cursorColor = AccentBlue,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                    maxLines = 3
                )

                // Voice button
                IconButton(
                    onClick = onVoice,
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    Icon(
                        if (isListening) Icons.Filled.MicOff else Icons.Filled.Mic,
                        contentDescription = "Voice",
                        tint = if (isListening) AccentBlue else DarkOnSurface.copy(alpha = 0.5f)
                    )
                }

                // Send / Loading button
                Box(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (value.isNotBlank() && !isLoading) AccentBlue
                            else DarkOutline
                        )
                        .clickable(
                            enabled = value.isNotBlank() && !isLoading,
                            onClick = onSend
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = DarkOnSurface,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            Icons.Filled.Send,
                            contentDescription = "Send",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            if (isListening) {
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        "Listening…",
                        style = MaterialTheme.typography.labelSmall.copy(color = AccentBlue)
                    )
                }
            }
        }
    }
}

@Composable
private fun ResultCard(result: String, isError: Boolean) {
    val color = if (isError) AccentRed else AccentGreen
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.1f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                if (isError) Icons.Filled.ErrorOutline else Icons.Filled.CheckCircleOutline,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(18.dp).padding(top = 2.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                result,
                style = MaterialTheme.typography.bodyMedium.copy(color = DarkOnSurface),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun HistoryCard(item: HistoryItem) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (item.success) AccentGreen else AccentRed)
                    .padding(top = 6.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    item.command,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = DarkOnSurface,
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    item.response,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = DarkOnSurface.copy(alpha = 0.55f),
                        fontSize = 12.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    fmt.format(Date(item.timestamp)),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = DarkOnSurface.copy(alpha = 0.4f)
                    )
                )
                if (item.tokensUsed > 0) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "${item.tokensUsed}t",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AccentPurple.copy(alpha = 0.7f),
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Outlined.TouchApp,
                contentDescription = null,
                tint = DarkOnSurface.copy(alpha = 0.2f),
                modifier = Modifier.size(64.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "Type a command or tap the mic",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = DarkOnSurface.copy(alpha = 0.35f),
                    textAlign = TextAlign.Center
                )
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "\"Open WhatsApp and message Mom\"",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = DarkOnSurface.copy(alpha = 0.2f),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            )
        }
    }
}
