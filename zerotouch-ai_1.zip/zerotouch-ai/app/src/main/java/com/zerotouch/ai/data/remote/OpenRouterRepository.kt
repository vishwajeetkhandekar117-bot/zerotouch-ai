package com.zerotouch.ai.data.remote

import com.google.gson.Gson
import com.zerotouch.ai.data.model.AgentResponse
import com.zerotouch.ai.data.model.OpenRouterMessage
import com.zerotouch.ai.data.model.OpenRouterRequest
import com.zerotouch.ai.data.model.OpenRouterResult
import com.zerotouch.ai.data.local.CommandHistoryDao
import com.zerotouch.ai.data.model.CommandHistoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OpenRouterRepository @Inject constructor(
    private val apiService: OpenRouterApiService,
    private val gson: Gson,
    private val historyDao: CommandHistoryDao
) {
    companion object {
        val MODELS = listOf(
            "openai/gpt-4o-mini",
            "mistralai/mistral-7b-instruct",
            "google/gemini-flash-1.5"
        )

        val SYSTEM_PROMPT = """
You are ZeroTouch AI, an Android phone automation agent. You control the phone via accessibility actions.

CRITICAL RULES:
1. ALWAYS respond in valid JSON only. No markdown, no explanations outside JSON.
2. Use "find_element" instead of hard coordinates whenever possible.
3. If an element might not be found, include fallbackX and fallbackY.
4. Add "wait" actions between screen transitions (1000-2000ms).
5. For text input: first tap the input field, then type_text.
6. Available findBy values: "text", "content-desc", "resource-id", "class".

Available actions:
- launch_app: Open app by package name {"type":"launch_app","packageName":"com.example"}
- tap: Tap at coordinates {"type":"tap","x":500,"y":800}
- long_press: Long press {"type":"long_press","x":500,"y":800}
- type_text: Type text {"type":"type_text","text":"Hello"}
- press_back: Android back button {"type":"press_back"}
- press_home: Android home button {"type":"press_home"}
- scroll: Scroll direction {"type":"scroll","direction":"down"}
- find_element: Find UI element then tap {"type":"find_element","findBy":"text","findValue":"Send","fallbackX":900,"fallbackY":1800}
- wait: Wait ms {"type":"wait","duration":1500}
- swipe: Swipe gesture {"type":"swipe","startX":500,"startY":1000,"endX":500,"endY":300,"duration":500}

Package names for common apps:
- WhatsApp: com.whatsapp
- Instagram: com.instagram.android
- YouTube: com.google.android.youtube
- Maps: com.google.android.apps.maps
- Chrome: com.android.chrome
- Settings: com.android.settings
- Phone: com.android.dialer
- Messages: com.google.android.apps.messaging
- Camera: com.android.camera2
- Gmail: com.google.android.gm
- Twitter/X: com.twitter.android
- Spotify: com.spotify.music
- Netflix: com.netflix.mediaclient

Response format (ALWAYS use this exact structure):
{
  "actions": [...],
  "confirmation": "Human-readable description of what was done",
  "requiresConfirmation": false
}
        """.trimIndent()
    }

    suspend fun processCommand(
        userCommand: String,
        screenContext: String? = null,
        apiKey: String,
        modelIndex: Int = 0
    ): OpenRouterResult<AgentResponse> = withContext(Dispatchers.IO) {
        val model = MODELS.getOrElse(modelIndex) { MODELS[0] }

        try {
            val content = buildString {
                append("User command: $userCommand\n")
                if (!screenContext.isNullOrBlank()) {
                    append("\nCurrent screen elements:\n$screenContext")
                }
            }

            val request = OpenRouterRequest(
                model = model,
                messages = listOf(
                    OpenRouterMessage(role = "system", content = SYSTEM_PROMPT),
                    OpenRouterMessage(role = "user", content = content)
                ),
                temperature = 0.2,
                maxTokens = 1024
            )

            val response = apiService.chatCompletion(
                auth = "Bearer $apiKey",
                request = request
            )

            val assistantMessage = response.choices.firstOrNull()?.message?.content
                ?: return@withContext OpenRouterResult.Error("Empty AI response")

            val cleanJson = assistantMessage
                .replace(Regex("```json\\s*"), "")
                .replace(Regex("```\\s*"), "")
                .trim()

            val agentResponse = gson.fromJson(cleanJson, AgentResponse::class.java)
            val tokens = response.usage?.totalTokens ?: 0

            // Save to history
            historyDao.insert(
                CommandHistoryEntity(
                    command = userCommand,
                    response = agentResponse.confirmation,
                    success = true,
                    tokensUsed = tokens
                )
            )

            OpenRouterResult.Success(agentResponse, tokens)

        } catch (e: Exception) {
            // Try next model on failure if not last
            if (modelIndex < MODELS.size - 1) {
                return@withContext processCommand(userCommand, screenContext, apiKey, modelIndex + 1)
            }
            historyDao.insert(
                CommandHistoryEntity(
                    command = userCommand,
                    response = "Error: ${e.message}",
                    success = false
                )
            )
            OpenRouterResult.Error(e.message ?: "Unknown error")
        }
    }

    suspend fun getHistory() = historyDao.getAll()
    suspend fun clearHistory() = historyDao.clearAll()
}
