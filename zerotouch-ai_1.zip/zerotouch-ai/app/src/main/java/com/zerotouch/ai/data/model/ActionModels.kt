package com.zerotouch.ai.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ActionType {
    LAUNCH_APP, TAP, LONG_PRESS, SWIPE, TYPE_TEXT,
    PRESS_BACK, PRESS_HOME, PRESS_RECENT, SCROLL,
    FIND_ELEMENT, WAIT, SCREENSHOT
}

data class AgentAction(
    val type: String,
    val packageName: String? = null,
    val x: Int? = null,
    val y: Int? = null,
    val text: String? = null,
    val direction: String? = null,
    val duration: Long? = null,
    val findBy: String? = null,
    val findValue: String? = null,
    val fallbackX: Int? = null,
    val fallbackY: Int? = null,
    val startX: Int? = null,
    val startY: Int? = null,
    val endX: Int? = null,
    val endY: Int? = null
)

data class AgentResponse(
    val actions: List<AgentAction>,
    val confirmation: String,
    val requiresConfirmation: Boolean = false
)

data class ScreenElement(
    val text: String?,
    val contentDescription: String?,
    val resourceId: String?,
    val className: String?,
    val bounds: Bounds,
    val isClickable: Boolean,
    val isEditable: Boolean
)

data class Bounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    fun centerX(): Int = (left + right) / 2
    fun centerY(): Int = (top + bottom) / 2
    override fun toString(): String = "($left,$top)-($right,$bottom)"
}

@Entity(tableName = "command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val command: String,
    val response: String,
    val timestamp: Long = System.currentTimeMillis(),
    val success: Boolean = true,
    val tokensUsed: Int = 0
)
