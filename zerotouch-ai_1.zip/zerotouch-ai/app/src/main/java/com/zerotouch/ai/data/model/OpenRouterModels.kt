package com.zerotouch.ai.data.model

import com.google.gson.annotations.SerializedName

data class OpenRouterRequest(
    val model: String = "openai/gpt-4o-mini",
    val messages: List<OpenRouterMessage>,
    val temperature: Double = 0.2,
    @SerializedName("max_tokens")
    val maxTokens: Int = 1024
)

data class OpenRouterMessage(
    val role: String,
    val content: String
)

data class OpenRouterResponse(
    val choices: List<OpenRouterChoice>,
    val usage: OpenRouterUsage?,
    val model: String?
)

data class OpenRouterChoice(
    val message: OpenRouterMessage,
    @SerializedName("finish_reason")
    val finishReason: String?,
    val index: Int = 0
)

data class OpenRouterUsage(
    @SerializedName("prompt_tokens")
    val promptTokens: Int,
    @SerializedName("completion_tokens")
    val completionTokens: Int,
    @SerializedName("total_tokens")
    val totalTokens: Int
)

sealed class OpenRouterResult<out T> {
    data class Success<T>(val data: T, val tokensUsed: Int = 0) : OpenRouterResult<T>()
    data class Error(val message: String, val code: Int? = null) : OpenRouterResult<Nothing>()
    object Loading : OpenRouterResult<Nothing>()
}
