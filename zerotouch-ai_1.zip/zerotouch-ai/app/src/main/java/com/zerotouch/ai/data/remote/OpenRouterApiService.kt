package com.zerotouch.ai.data.remote

import com.zerotouch.ai.data.model.OpenRouterRequest
import com.zerotouch.ai.data.model.OpenRouterResponse
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface OpenRouterApiService {

    @POST("chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") auth: String,
        @Header("HTTP-Referer") referer: String = "https://zerotouch.ai",
        @Header("X-Title") title: String = "ZeroTouch AI",
        @Body request: OpenRouterRequest
    ): OpenRouterResponse
}
