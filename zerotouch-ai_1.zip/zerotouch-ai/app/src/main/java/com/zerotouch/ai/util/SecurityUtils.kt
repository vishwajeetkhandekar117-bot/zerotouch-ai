package com.zerotouch.ai.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecurityUtils {

    private fun getEncryptedPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        return EncryptedSharedPreferences.create(
            context,
            "zerotouch_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun saveApiKey(context: Context, apiKey: String) {
        getEncryptedPrefs(context).edit().putString(Constants.KEY_API_KEY, apiKey).apply()
    }

    fun getApiKey(context: Context): String {
        return getEncryptedPrefs(context).getString(Constants.KEY_API_KEY, "") ?: ""
    }

    fun clearApiKey(context: Context) {
        getEncryptedPrefs(context).edit().remove(Constants.KEY_API_KEY).apply()
    }

    fun hasApiKey(context: Context): Boolean = getApiKey(context).isNotBlank()
}
