package com.zerotouch.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val command: String,
    val response: String,
    val timestamp: Long = System.currentTimeMillis(),
    val success: Boolean = true,
    val tokensUsed: Int = 0
)
