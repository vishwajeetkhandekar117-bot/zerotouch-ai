package com.zerotouch.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.zerotouch.ai.engine.ActionEngine
import com.zerotouch.ai.engine.ElementFinder
import com.zerotouch.ai.engine.ScreenAnalyzer

class ZeroTouchAccessibilityService : AccessibilityService() {

    private var screenAnalyzer: ScreenAnalyzer? = null
    private var elementFinder: ElementFinder? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        screenAnalyzer = ScreenAnalyzer()
        elementFinder = ElementFinder()

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Events handled on-demand via getScreenContext()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun getScreenContext(): String {
        val root = rootInActiveWindow ?: return "No screen content available"
        return screenAnalyzer?.analyzeScreen(root) ?: "Analyzer not ready"
    }

    fun createActionEngine(): ActionEngine {
        return ActionEngine(this, elementFinder ?: ElementFinder())
    }

    companion object {
        @Volatile
        var instance: ZeroTouchAccessibilityService? = null
            private set

        val isEnabled: Boolean get() = instance != null
    }
}
