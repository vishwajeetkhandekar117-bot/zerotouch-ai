package com.zerotouch.ai.util

object Constants {
    const val OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1/"
    const val PREFS_NAME = "zerotouch_prefs"
    const val KEY_API_KEY = "api_key"
    const val KEY_SELECTED_MODEL = "selected_model"
    const val KEY_TTS_ENABLED = "tts_enabled"
    const val KEY_CONFIRMATION_REQUIRED = "confirmation_required"
    const val KEY_OVERLAY_ENABLED = "overlay_enabled"

    val AVAILABLE_MODELS = listOf(
        "openai/gpt-4o-mini",
        "mistralai/mistral-7b-instruct",
        "google/gemini-flash-1.5"
    )

    val APP_PACKAGES = mapOf(
        "WhatsApp" to "com.whatsapp",
        "Instagram" to "com.instagram.android",
        "YouTube" to "com.google.android.youtube",
        "Maps" to "com.google.android.apps.maps",
        "Chrome" to "com.android.chrome",
        "Settings" to "com.android.settings",
        "Phone" to "com.android.dialer",
        "Messages" to "com.google.android.apps.messaging",
        "Gmail" to "com.google.android.gm",
        "Twitter/X" to "com.twitter.android",
        "Spotify" to "com.spotify.music",
        "Netflix" to "com.netflix.mediaclient",
        "Camera" to "com.android.camera2"
    )
}
