package com.zerotouch.ai.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFF9ECAFF)
val BlueGrey80 = Color(0xFFB0C4DE)
val Green80 = Color(0xFF81C995)

val Blue40 = Color(0xFF1A73E8)
val BlueGrey40 = Color(0xFF5C7A9B)
val Green40 = Color(0xFF34A853)

// Dark theme surface colors (GitHub-inspired dark)
val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF21262D)
val DarkOnSurface = Color(0xFFE6EDF3)
val DarkOutline = Color(0xFF30363D)

val AccentBlue = Color(0xFF1A73E8)
val AccentGreen = Color(0xFF3FB950)
val AccentRed = Color(0xFFF85149)
val AccentYellow = Color(0xFFD29922)
val AccentPurple = Color(0xFFA371F7)
