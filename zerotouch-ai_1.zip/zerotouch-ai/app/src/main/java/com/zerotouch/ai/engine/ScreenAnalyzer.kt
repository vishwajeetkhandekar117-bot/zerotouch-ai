package com.zerotouch.ai.engine

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.zerotouch.ai.data.model.Bounds
import com.zerotouch.ai.data.model.ScreenElement

class ScreenAnalyzer {

    fun analyzeScreen(rootNode: AccessibilityNodeInfo): String {
        val elements = mutableListOf<ScreenElement>()
        collectInteractiveElements(rootNode, elements)

        return buildString {
            elements.take(50).forEach { el ->
                val parts = mutableListOf<String>()
                if (!el.text.isNullOrBlank()) parts.add("text='${el.text}'")
                if (!el.contentDescription.isNullOrBlank()) parts.add("desc='${el.contentDescription}'")
                if (!el.resourceId.isNullOrBlank()) {
                    val shortId = el.resourceId.substringAfterLast("/")
                    parts.add("id='$shortId'")
                }
                if (el.isEditable) parts.add("editable=true")
                if (el.isClickable) parts.add("clickable=true")
                parts.add("bounds=${el.bounds}")
                appendLine("[${el.className?.substringAfterLast(".") ?: "View"}] ${parts.joinToString(" ")}")
            }
        }.trim()
    }

    fun getAllElements(node: AccessibilityNodeInfo): List<ScreenElement> {
        val list = mutableListOf<ScreenElement>()
        collectAllNodes(node, list)
        return list
    }

    private fun collectInteractiveElements(
        node: AccessibilityNodeInfo,
        list: MutableList<ScreenElement>
    ) {
        val hasText = !node.text.isNullOrBlank()
        val hasDesc = !node.contentDescription.isNullOrBlank()
        val isClickable = node.isClickable
        val isEditable = node.isEditable

        if (hasText || hasDesc || isClickable || isEditable) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (rect.width() > 0 && rect.height() > 0) {
                list.add(node.toScreenElement())
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectInteractiveElements(child, list)
        }
    }

    private fun collectAllNodes(node: AccessibilityNodeInfo, list: MutableList<ScreenElement>) {
        list.add(node.toScreenElement())
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectAllNodes(child, list)
        }
    }

    private fun AccessibilityNodeInfo.toScreenElement(): ScreenElement {
        val rect = Rect()
        getBoundsInScreen(rect)
        return ScreenElement(
            text = text?.toString(),
            contentDescription = contentDescription?.toString(),
            resourceId = viewIdResourceName,
            className = className?.toString(),
            bounds = Bounds(rect.left, rect.top, rect.right, rect.bottom),
            isClickable = isClickable,
            isEditable = isEditable
        )
    }
}
