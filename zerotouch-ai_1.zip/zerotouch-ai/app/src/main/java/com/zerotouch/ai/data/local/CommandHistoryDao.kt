package com.zerotouch.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CommandHistoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: CommandHistoryEntity)

    @Query("SELECT * FROM command_history ORDER BY timestamp DESC LIMIT 100")
    fun observeAll(): Flow<List<CommandHistoryEntity>>

    @Query("SELECT * FROM command_history ORDER BY timestamp DESC LIMIT 100")
    suspend fun getAll(): List<CommandHistoryEntity>

    @Query("DELETE FROM command_history")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM command_history WHERE success = 1")
    suspend fun getSuccessCount(): Int

    @Query("SELECT SUM(tokensUsed) FROM command_history")
    suspend fun getTotalTokensUsed(): Int
}
