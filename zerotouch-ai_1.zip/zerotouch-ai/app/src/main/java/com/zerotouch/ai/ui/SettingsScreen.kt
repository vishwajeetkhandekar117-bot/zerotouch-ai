package com.zerotouch.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zerotouch.ai.data.remote.OpenRouterRepository
import com.zerotouch.ai.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showApiKey by remember { mutableStateOf(false) }
    var apiKeyInput by remember { mutableStateOf(uiState.apiKey) }
    var showClearDialog by remember { mutableStateOf(false) }

    ZeroTouchTheme {
        Scaffold(
            containerColor = DarkBackground,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            "Settings",
                            style = MaterialTheme.typography.titleLarge.copy(color = DarkOnSurface)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = DarkOnSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // API Key Section
                SettingsSection(title = "API Key") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = { apiKeyInput = it },
                            label = { Text("OpenRouter API Key", color = DarkOnSurface.copy(0.6f)) },
                            placeholder = { Text("sk-or-...", color = DarkOnSurface.copy(0.3f)) },
                            visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { showApiKey = !showApiKey }) {
                                    Icon(
                                        if (showApiKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        contentDescription = "Toggle visibility",
                                        tint = DarkOnSurface.copy(0.5f)
                                    )
                                }
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AccentBlue,
                                unfocusedBorderColor = DarkOutline,
                                focusedTextColor = DarkOnSurface,
                                unfocusedTextColor = DarkOnSurface,
                                cursorColor = AccentBlue,
                                focusedContainerColor = DarkSurfaceVariant,
                                unfocusedContainerColor = DarkSurfaceVariant
                            )
                        )
                        Button(
                            onClick = {
                                viewModel.saveApiKey(context, apiKeyInput)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Save API Key")
                        }
                        Text(
                            "Get your key at openrouter.ai/keys",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = DarkOnSurface.copy(alpha = 0.4f),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Model Selection
                SettingsSection(title = "AI Model") {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OpenRouterRepository.MODELS.forEach { model ->
                            val isSelected = uiState.selectedModel == model
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) AccentBlue.copy(0.15f) else DarkSurfaceVariant
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) AccentBlue.copy(0.5f) else DarkOutline,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { viewModel.setModel(context, model) }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { viewModel.setModel(context, model) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = AccentBlue,
                                        unselectedColor = DarkOnSurface.copy(0.4f)
                                    )
                                )
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(
                                        model,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = DarkOnSurface,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    )
                                    val desc = when {
                                        "gpt-4o-mini" in model -> "Primary · Fastest & cheapest"
                                        "mistral" in model -> "Fallback · Free-tier friendly"
                                        "gemini" in model -> "Alternative · Google"
                                        else -> ""
                                    }
                                    if (desc.isNotBlank()) {
                                        Text(
                                            desc,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = DarkOnSurface.copy(0.45f)
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Permissions Section
                SettingsSection(title = "Permissions") {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        PermissionRow(
                            icon = Icons.Outlined.Accessibility,
                            label = "Accessibility Service",
                            isGranted = uiState.isAccessibilityEnabled,
                            onClick = { viewModel.openAccessibilitySettings(context) }
                        )
                        PermissionRow(
                            icon = Icons.Outlined.Layers,
                            label = "Overlay Permission",
                            isGranted = uiState.isOverlayGranted,
                            onClick = { viewModel.openOverlaySettings(context) }
                        )
                        PermissionRow(
                            icon = Icons.Outlined.Mic,
                            label = "Microphone",
                            isGranted = uiState.isMicGranted,
                            onClick = { /* request mic */ }
                        )
                    }
                }

                // Behaviour Section
                SettingsSection(title = "Behaviour") {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        ToggleRow(
                            icon = Icons.Outlined.RecordVoiceOver,
                            label = "Text-to-speech feedback",
                            checked = uiState.ttsEnabled,
                            onCheckedChange = { viewModel.setTtsEnabled(context, it) }
                        )
                        ToggleRow(
                            icon = Icons.Outlined.VerifiedUser,
                            label = "Require confirmation before executing",
                            checked = uiState.confirmationRequired,
                            onCheckedChange = { viewModel.setConfirmationRequired(context, it) }
                        )
                        ToggleRow(
                            icon = Icons.Outlined.PictureInPicture,
                            label = "Show floating button",
                            checked = uiState.overlayEnabled,
                            onCheckedChange = { viewModel.setOverlayEnabled(context, it) }
                        )
                    }
                }

                // Stats & History
                SettingsSection(title = "Usage & History") {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        StatRow("Commands executed", uiState.commandCount.toString())
                        StatRow("Total tokens used", uiState.totalTokens.toString())
                        Spacer(Modifier.height(4.dp))
                        OutlinedButton(
                            onClick = { showClearDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentRed),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AccentRed.copy(0.4f))
                        ) {
                            Icon(Icons.Outlined.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Clear History")
                        }
                    }
                }

                Spacer(Modifier.height(32.dp))
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear History?", color = DarkOnSurface) },
            text = { Text("This will delete all command history. This cannot be undone.", color = DarkOnSurface.copy(0.7f)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearHistory()
                    showClearDialog = false
                }) { Text("Clear", color = AccentRed) }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("Cancel", color = DarkOnSurface.copy(0.6f)) }
            },
            containerColor = DarkSurface
        )
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(
            title.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                color = DarkOnSurface.copy(0.5f),
                letterSpacing = 1.2.sp
            ),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.padding(14.dp)) { content() }
        }
    }
}

@Composable
private fun PermissionRow(icon: ImageVector, label: String, isGranted: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .clickable(enabled = !isGranted, onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = DarkOnSurface.copy(0.6f), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium.copy(color = DarkOnSurface), modifier = Modifier.weight(1f))
        if (isGranted) {
            Icon(Icons.Filled.CheckCircle, contentDescription = "Granted", tint = AccentGreen, modifier = Modifier.size(18.dp))
        } else {
            Text("Grant", style = MaterialTheme.typography.labelSmall.copy(color = AccentBlue))
        }
    }
}

@Composable
private fun ToggleRow(icon: ImageVector, label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = DarkOnSurface.copy(0.6f), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium.copy(color = DarkOnSurface), modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = AccentBlue,
                uncheckedThumbColor = DarkOnSurface.copy(0.4f),
                uncheckedTrackColor = DarkOutline
            )
        )
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium.copy(color = DarkOnSurface.copy(0.6f)), modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium.copy(color = DarkOnSurface, fontFamily = FontFamily.Monospace))
    }
}
