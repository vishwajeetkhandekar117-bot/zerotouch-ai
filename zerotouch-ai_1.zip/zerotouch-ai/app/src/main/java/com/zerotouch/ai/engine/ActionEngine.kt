package com.zerotouch.ai.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import com.zerotouch.ai.data.model.AgentAction
import com.zerotouch.ai.data.model.AgentResponse
import kotlinx.coroutines.delay

class ActionEngine(
    private val service: AccessibilityService,
    private val elementFinder: ElementFinder
) {
    suspend fun executeResponse(response: AgentResponse): Boolean {
        for (action in response.actions) {
            val success = executeAction(action)
            if (!success) {
                // Non-fatal — continue with next action
            }
        }
        return true
    }

    private suspend fun executeAction(action: AgentAction): Boolean {
        return when (action.type.lowercase()) {
            "launch_app" -> launchApp(action.packageName ?: return false)
            "tap" -> tap(action.x ?: return false, action.y ?: return false)
            "long_press" -> longPress(action.x ?: return false, action.y ?: return false)
            "type_text" -> typeText(action.text ?: return false)
            "press_back" -> pressBack()
            "press_home" -> pressHome()
            "press_recent" -> pressRecent()
            "scroll" -> scroll(action.direction ?: "down")
            "swipe" -> swipe(
                action.startX ?: return false,
                action.startY ?: return false,
                action.endX ?: return false,
                action.endY ?: return false,
                action.duration ?: 500L
            )
            "find_element" -> findAndTap(
                action.findBy ?: return false,
                action.findValue ?: return false,
                action.fallbackX,
                action.fallbackY
            )
            "wait" -> {
                delay(action.duration ?: 1000L)
                true
            }
            "screenshot" -> true // Handled by service
            else -> false
        }
    }

    private fun launchApp(packageName: String): Boolean {
        return try {
            val intent = service.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                service.startActivity(intent)
                true
            } else false
        } catch (e: Exception) { false }
    }

    private suspend fun tap(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        var done = false
        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) { done = true }
            override fun onCancelled(gestureDescription: GestureDescription) { done = true }
        }, null)
        // Wait briefly for gesture to register
        delay(200)
        return true
    }

    private suspend fun longPress(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 800)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        service.dispatchGesture(gesture, null, null)
        delay(900)
        return true
    }

    private fun typeText(text: String): Boolean {
        val node = service.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return if (node != null) {
            val args = Bundle().apply { putString(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } else false
    }

    private fun pressBack(): Boolean {
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        return true
    }

    private fun pressHome(): Boolean {
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        return true
    }

    private fun pressRecent(): Boolean {
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
        return true
    }

    private suspend fun scroll(direction: String): Boolean {
        val displayMetrics = service.resources.displayMetrics
        val w = displayMetrics.widthPixels
        val h = displayMetrics.heightPixels
        val cx = w / 2

        val (startY, endY) = when (direction.lowercase()) {
            "up" -> Pair(h / 3, 2 * h / 3)
            "down" -> Pair(2 * h / 3, h / 3)
            "left" -> Pair(w / 2, w / 4) // handled as x swipe below
            "right" -> Pair(w / 4, w / 2)
            else -> Pair(2 * h / 3, h / 3)
        }

        return if (direction in listOf("left", "right")) {
            swipe(startY, h / 2, endY, h / 2, 400L)
        } else {
            swipe(cx, startY, cx, endY, 400L)
        }
    }

    private suspend fun swipe(startX: Int, startY: Int, endX: Int, endY: Int, duration: Long): Boolean {
        val path = Path().apply {
            moveTo(startX.toFloat(), startY.toFloat())
            lineTo(endX.toFloat(), endY.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        service.dispatchGesture(gesture, null, null)
        delay(duration + 100)
        return true
    }

    private suspend fun findAndTap(by: String, value: String, fallbackX: Int?, fallbackY: Int?): Boolean {
        val root = service.rootInActiveWindow ?: return false
        val element = elementFinder.findElement(root, by, value)
        return if (element != null) {
            tap(element.bounds.centerX(), element.bounds.centerY())
        } else if (fallbackX != null && fallbackY != null) {
            tap(fallbackX, fallbackY)
        } else false
    }
}
