package com.zerotouch.ai.engine

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.zerotouch.ai.data.model.Bounds
import com.zerotouch.ai.data.model.ScreenElement

class ElementFinder {

    fun findElement(
        rootNode: AccessibilityNodeInfo,
        by: String,
        value: String
    ): ScreenElement? {
        return when (by.lowercase()) {
            "text" -> findByText(rootNode, value)
            "content-desc" -> findByContentDesc(rootNode, value)
            "resource-id" -> findByResourceId(rootNode, value)
            "class" -> findByClassName(rootNode, value)
            else -> null
        }
    }

    private fun findByText(node: AccessibilityNodeInfo, text: String): ScreenElement? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true) {
            return node.toScreenElement()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findByText(child, text)
            if (result != null) return result
        }
        return null
    }

    private fun findByContentDesc(node: AccessibilityNodeInfo, desc: String): ScreenElement? {
        if (node.contentDescription?.toString()?.contains(desc, ignoreCase = true) == true) {
            return node.toScreenElement()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findByContentDesc(child, desc)
            if (result != null) return result
        }
        return null
    }

    private fun findByResourceId(node: AccessibilityNodeInfo, id: String): ScreenElement? {
        if (node.viewIdResourceName?.contains(id, ignoreCase = true) == true) {
            return node.toScreenElement()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findByResourceId(child, id)
            if (result != null) return result
        }
        return null
    }

    private fun findByClassName(node: AccessibilityNodeInfo, className: String): ScreenElement? {
        if (node.className?.toString()?.contains(className, ignoreCase = true) == true) {
            return node.toScreenElement()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findByClassName(child, className)
            if (result != null) return result
        }
        return null
    }

    private fun AccessibilityNodeInfo.toScreenElement(): ScreenElement {
        val rect = Rect()
        getBoundsInScreen(rect)
        return ScreenElement(
            text = text?.toString(),
            contentDescription = contentDescription?.toString(),
            resourceId = viewIdResourceName,
            className = className?.toString(),
            bounds = Bounds(rect.left, rect.top, rect.right, rect.bottom),
            isClickable = isClickable,
            isEditable = isEditable
        )
    }
}
