# Add project specific ProGuard rules here.

# Keep accessibility service
-keep class com.zerotouch.ai.service.** { *; }

# Keep data models (used by Gson reflection)
-keep class com.zerotouch.ai.data.model.** { *; }

# Gson generic type information
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# OkHttp / Retrofit
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }

# Hilt
-keep class * extends dagger.hilt.android.HiltAndroidApp
-keep class dagger.hilt.** { *; }

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
