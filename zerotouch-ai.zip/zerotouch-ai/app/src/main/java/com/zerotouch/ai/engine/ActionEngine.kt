package com.zerotouch.ai.engine

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.zerotouch.ai.data.model.ActionType
import com.zerotouch.ai.data.model.AgentAction
import com.zerotouch.ai.data.model.AgentResponse
import com.zerotouch.ai.data.model.Bounds
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Result of executing one [AgentAction].
 */
sealed class ActionResult {
    data class Success(val message: String = "ok") : ActionResult()
    data class Failure(val message: String, val cause: Throwable? = null) : ActionResult()
}

/**
 * Execution summary for an entire [AgentResponse].
 */
data class ExecutionResult(
    val total: Int,
    val succeeded: Int,
    val failed: Int,
    val steps: List<StepRecord>
) {
    val ok: Boolean get() = failed == 0
    val summary: String get() = "$succeeded/$total actions OK" +
        if (failed > 0) " — $failed failed" else ""
}

data class StepRecord(
    val index: Int,
    val action: AgentAction,
    val result: ActionResult,
    val tookMs: Long
)

/**
 * The brain of ZeroTouch — takes AI-returned actions and drives the UI
 * via the [ActionExecutor] abstraction (which is bound to our
 * AccessibilityService at runtime).
 *
 * Designed to be safe, retry-aware, and pause-able.
 */
@Singleton
class ActionEngine @Inject constructor(
    private val context: Context,
    private val elementFinder: ElementFinder,
    private val screenAnalyzer: ScreenAnalyzer
) {

    @Volatile
    private var executor: ActionExecutor? = null

    @Volatile
    private var stopped: Boolean = false

    /** Called by the AccessibilityService when it connects/disconnects. */
    fun bindExecutor(e: ActionExecutor?) {
        executor = e
        Log.i(TAG, "executor bound: ${e != null}")
    }

    fun stop() {
        stopped = true
    }

    fun reset() {
        stopped = false
    }

    fun isReady(): Boolean = executor?.isReady() == true

    suspend fun execute(response: AgentResponse): ExecutionResult {
        reset()
        val ex = executor
        if (ex == null || !ex.isReady()) {
            return ExecutionResult(0, 0, 0, emptyList()).copy(
                // we encode the failure in the steps list as a single "global" failure
                // by returning a special result. Caller can detect via summary.
            ).also {
                Log.w(TAG, "execute() called but executor not ready")
            }
        }

        val records = mutableListOf<StepRecord>()
        var okCount = 0
        var failCount = 0

        response.actions.forEachIndexed { idx, action ->
            if (stopped) {
                records += StepRecord(idx, action, ActionResult.Failure("stopped by user"), 0)
                failCount++
                return@forEachIndexed
            }

            val start = System.currentTimeMillis()
            val result = runCatching { runAction(ex, action) }
                .getOrElse { ActionResult.Failure(it.message ?: "unknown", it) }
            val took = System.currentTimeMillis() - start

            records += StepRecord(idx, action, result, took)
            when (result) {
                is ActionResult.Success -> okCount++
                is ActionResult.Failure -> failCount++
            }

            // Inter-action settle delay so UI can update
            delay(DEFAULT_SETTLE_MS)
        }

        return ExecutionResult(
            total = response.actions.size,
            succeeded = okCount,
            failed = failCount,
            steps = records
        )
    }

    /**
     * Execute a single action with simple retry logic.
     */
    private suspend fun runAction(ex: ActionExecutor, action: AgentAction): ActionResult {
        val type = action.resolvedType
            ?: return ActionResult.Failure("unknown action type '${action.type}'")

        repeat(MAX_ATTEMPTS) { attempt ->
            val r = performSingle(ex, type, action)
            if (r is ActionResult.Success) return r
            if (attempt < MAX_ATTEMPTS - 1) delay(RETRY_BACKOFF_MS)
        }
        return ActionResult.Failure("failed after $MAX_ATTEMPTS attempts: ${action.type}")
    }

    private suspend fun performSingle(
        ex: ActionExecutor,
        type: ActionType,
        action: AgentAction
    ): ActionResult {
        return when (type) {
            ActionType.LaunchApp -> launchApp(action.packageName)
            ActionType.Tap -> {
                val x = action.x ?: return ActionResult.Failure("tap: x missing")
                val y = action.y ?: return ActionResult.Failure("tap: y missing")
                if (ex.tap(x, y)) ActionResult.Success("tap($x,$y)")
                else ActionResult.Failure("tap gesture failed")
            }
            ActionType.LongPress -> {
                val x = action.x ?: return ActionResult.Failure("long_press: x missing")
                val y = action.y ?: return ActionResult.Failure("long_press: y missing")
                val dur = action.durationMs ?: 600L
                if (ex.longPress(x, y, dur)) ActionResult.Success("long_press($x,$y,${dur}ms)")
                else ActionResult.Failure("long_press gesture failed")
            }
            ActionType.Swipe -> {
                val x1 = action.x ?: return ActionResult.Failure("swipe: x missing")
                val y1 = action.y ?: return ActionResult.Failure("swipe: y missing")
                val x2 = action.x2 ?: return ActionResult.Failure("swipe: x2 missing")
                val y2 = action.y2 ?: return ActionResult.Failure("swipe: y2 missing")
                val dur = action.durationMs ?: 300L
                if (ex.swipe(x1, y1, x2, y2, dur)) ActionResult.Success("swipe($x1,$y1)->($x2,$y2)")
                else ActionResult.Failure("swipe gesture failed")
            }
            ActionType.TypeText -> {
                val text = action.text ?: return ActionResult.Failure("type_text: text missing")
                if (ex.typeText(text)) ActionResult.Success("type_text(${text.length} chars)")
                else ActionResult.Failure("type_text failed — no focused field?")
            }
            ActionType.PressBack -> if (ex.pressBack()) ActionResult.Success("back") else ActionResult.Failure("back failed")
            ActionType.PressHome -> if (ex.pressHome()) ActionResult.Success("home") else ActionResult.Failure("home failed")
            ActionType.PressRecents -> if (ex.pressRecents()) ActionResult.Success("recents") else ActionResult.Failure("recents failed")
            ActionType.Scroll -> {
                val dir = action.direction ?: return ActionResult.Failure("scroll: direction missing")
                if (ex.scroll(dir)) ActionResult.Success("scroll($dir)") else ActionResult.Failure("scroll failed")
            }
            ActionType.FindAndTap -> {
                val byStr = action.findBy ?: return ActionResult.Failure("find_and_tap: findBy missing")
                val value = action.findValue ?: return ActionResult.Failure("find_and_tap: findValue missing")
                val by = ElementFinder.FindBy.parse(byStr)
                    ?: return ActionResult.Failure("find_and_tap: bad findBy '$byStr'")
                val root = ex.currentRootNode()
                val el = screenAnalyzer.findElement(root, by, value, exact = false)
                    ?: return ActionResult.Failure("find_and_tap: not found '$value' by $byStr")
                val cx = el.bounds.centerX
                val cy = el.bounds.centerY
                if (cx == 0 && cy == 0) return ActionResult.Failure("element has zero-area bounds")
                if (ex.tap(cx, cy)) ActionResult.Success("find_and_tap('$value') at $cx,$cy")
                else ActionResult.Failure("find_and_tap: tap failed")
            }
            ActionType.Wait -> {
                val ms = action.waitMs ?: 1000L
                delay(ms.coerceIn(0L, 10_000L))
                ActionResult.Success("wait(${ms}ms)")
            }
            ActionType.Screenshot -> {
                // Screenshot is not implementable via accessibility gestures alone;
                // we acknowledge it so the AI doesn't get into a retry loop.
                ActionResult.Success("screenshot requested (use device shortcut)")
            }
        }
    }

    private fun launchApp(packageName: String?): ActionResult {
        if (packageName.isNullOrBlank()) return ActionResult.Failure("launch_app: packageName missing")
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
                ?: Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(packageName)
            if (intent == null) {
                ActionResult.Failure("launch_app: no intent for $packageName")
            } else {
                intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                )
                context.startActivity(intent)
                ActionResult.Success("launch_app($packageName)")
            }
        } catch (t: Throwable) {
            ActionResult.Failure("launch_app exception: ${t.message}", t)
        }
    }

    companion object {
        private const val TAG = "ActionEngine"
        private const val DEFAULT_SETTLE_MS = 350L
        private const val MAX_ATTEMPTS = 2
        private const val RETRY_BACKOFF_MS = 400L
    }
}
