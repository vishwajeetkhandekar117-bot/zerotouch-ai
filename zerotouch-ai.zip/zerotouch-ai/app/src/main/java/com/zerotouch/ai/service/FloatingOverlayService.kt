package com.zerotouch.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.zerotouch.ai.R
import com.zerotouch.ai.engine.ActionEngine
import com.zerotouch.ai.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlin.math.max
import kotlin.math.min

/**
 * Transparent floating panel shown while an automation is running.
 *
 * What the user sees:
 *   - Top-right floating card with current step + progress.
 *   - "Stop" button that calls [ActionEngine.stop].
 *   - Tap-to-drag, tap-to-open-main-app behaviour.
 *
 * Bound to the action engine via a callback wired in MainActivity
 * (we don't need a permanent service — overlay lives only while running).
 */
@AndroidEntryPoint
class FloatingOverlayService : Service() {

    @Inject lateinit var actionEngine: ActionEngine

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private val stepViews = mutableListOf<TextView>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startInForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showOverlay()
            ACTION_HIDE -> hideOverlay()
            ACTION_UPDATE -> updateOverlay(
                totalSteps = intent.getIntExtra(EXTRA_TOTAL, 0),
                currentStep = intent.getIntExtra(EXTRA_CURRENT, 0),
                description = intent.getStringExtra(EXTRA_DESC).orEmpty()
            )
            ACTION_STOP -> {
                actionEngine.stop()
                hideOverlay()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }

    private fun startInForeground() {
        val channelId = CHANNEL_ID
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(channelId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Automation overlay", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shown while ZeroTouch is performing actions"
                    setShowBadge(false)
                }
            )
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.overlay_title))
            .setContentText(getString(R.string.status_executing))
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun showOverlay() {
        if (overlayView != null) return
        val inflater = LayoutInflater.from(this)
        val root = inflater.inflate(R.layout.overlay_status, null)

        val lpType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            lpType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = dp(16)
        params.y = dp(80)

        // Drag handler
        root.setOnTouchListener(object : View.OnTouchListener {
            var initX = 0; var initY = 0
            var touchX = 0f; var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initX = params.x; initY = params.y
                        touchX = event.rawX; touchY = event.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (touchX - event.rawX).toInt()
                        val dy = (touchY - event.rawY).toInt()
                        params.x = max(dp(-200), min(initX + dx, dp(200)))
                        params.y = max(dp(0), min(initY + dy, dp(1000)))
                        windowManager.updateViewLayout(root, params)
                    }
                    else -> return false
                }
                return true
            }
        })

        // Stop button
        root.findViewById<ImageButton>(R.id.btn_overlay_stop).setOnClickListener {
            actionEngine.stop()
            hideOverlay()
        }
        // Tap card to open app
        root.setOnClickListener {
            val open = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(open)
        }

        // Cache step text views
        stepViews.clear()
        stepViews += root.findViewById(R.id.tv_overlay_step1)
        stepViews += root.findViewById(R.id.tv_overlay_step2)
        stepViews += root.findViewById(R.id.tv_overlay_step3)

        try {
            windowManager.addView(root, params)
            overlayView = root
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to add overlay view", t)
        }
    }

    private fun updateOverlay(totalSteps: Int, currentStep: Int, description: String) {
        val v = overlayView ?: run { showOverlay(); return }
        v.findViewById<TextView>(R.id.tv_overlay_title).text =
            getString(R.string.overlay_title)
        v.findViewById<TextView>(R.id.tv_overlay_status).text =
            getString(R.string.overlay_step_format, currentStep, totalSteps, description)
        // Light up the appropriate progress dot
        val dots = listOf(
            v.findViewById<View>(R.id.dot1),
            v.findViewById<View>(R.id.dot2),
            v.findViewById<View>(R.id.dot3)
        )
        val active = ((currentStep - 1).coerceAtLeast(0)) % dots.size
        dots.forEachIndexed { idx, dot ->
            dot.setBackgroundColor(
                if (idx == active) Color.parseColor("#7C5CFF") else Color.parseColor("#404040")
            )
        }
    }

    private fun hideOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Throwable) {}
        }
        overlayView = null
        stopSelf()
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value.toFloat(),
            resources.displayMetrics
        ).toInt()

    companion object {
        private const val TAG = "FloatingOverlay"
        private const val CHANNEL_ID = "zerotouch_overlay"
        private const val NOTIF_ID = 4242

        const val ACTION_SHOW = "com.zerotouch.ai.SHOW"
        const val ACTION_HIDE = "com.zerotouch.ai.HIDE"
        const val ACTION_UPDATE = "com.zerotouch.ai.UPDATE"
        const val ACTION_STOP = "com.zerotouch.ai.STOP"

        const val EXTRA_TOTAL = "total"
        const val EXTRA_CURRENT = "current"
        const val EXTRA_DESC = "desc"

        fun show(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingOverlayService::class.java).setAction(ACTION_SHOW))
        }
        fun hide(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingOverlayService::class.java).setAction(ACTION_HIDE))
        }
        fun update(ctx: Context, total: Int, current: Int, desc: String) {
            ctx.startService(
                Intent(ctx, FloatingOverlayService::class.java)
                    .setAction(ACTION_UPDATE)
                    .putExtra(EXTRA_TOTAL, total)
                    .putExtra(EXTRA_CURRENT, current)
                    .putExtra(EXTRA_DESC, desc)
            )
        }
        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingOverlayService::class.java).setAction(ACTION_STOP))
        }
    }
}
