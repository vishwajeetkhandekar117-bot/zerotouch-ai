package com.zerotouch.ai.ui

import android.app.Application
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zerotouch.ai.R
import com.zerotouch.ai.data.model.AgentResponse
import com.zerotouch.ai.data.remote.MiniMaxRepository
import com.zerotouch.ai.engine.ActionEngine
import com.zerotouch.ai.engine.ExecutionResult
import com.zerotouch.ai.engine.ScreenAnalyzer
import com.zerotouch.ai.service.FloatingOverlayService
import com.zerotouch.ai.service.ZeroTouchAccessibilityService
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ExecState { IDLE, THINKING, EXECUTING, DONE, ERROR }

data class RecentCommand(val text: String, val ok: Boolean, val timestampMs: Long)

data class UiState(
    val draft: String = "",
    val state: ExecState = ExecState.IDLE,
    val accessibilityEnabled: Boolean = false,
    val overlayEnabled: Boolean = false,
    val currentConfirmation: String = "",
    val errorMessage: String? = null,
    val recent: List<RecentCommand> = emptyList(),
    val lastResponse: AgentResponse? = null,
    val lastResult: ExecutionResult? = null
)

@HiltViewModel
class MainViewModel @Inject constructor(
    app: Application,
    private val repo: MiniMaxRepository,
    private val actionEngine: ActionEngine,
    private val screenAnalyzer: ScreenAnalyzer
) : AndroidViewModel(app) {

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var runJob: Job? = null

    fun onDraftChanged(text: String) {
        _ui.update { it.copy(draft = text) }
    }

    fun refreshPermissionsState(
        accessibilityEnabled: Boolean,
        overlayEnabled: Boolean
    ) {
        _ui.update { it.copy(accessibilityEnabled = accessibilityEnabled, overlayEnabled = overlayEnabled) }
    }

    fun openAccessibilitySettings() {
        val ctx = getApplication<Application>()
        ctx.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun openOverlaySettings() {
        val ctx = getApplication<Application>()
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun stopExecution() {
        runJob?.cancel()
        actionEngine.stop()
        FloatingOverlayService.stop(getApplication())
        _ui.update { it.copy(state = ExecState.IDLE) }
    }

    fun execute(draft: String? = null) {
        val text = (draft ?: _ui.value.draft).trim()
        if (text.isEmpty()) return

        if (!_ui.value.accessibilityEnabled) {
            _ui.update { it.copy(errorMessage = getApplication<Application>().getString(R.string.err_no_a11y)) }
            return
        }
        if (!actionEngine.isReady()) {
            _ui.update { it.copy(errorMessage = "Accessibility service still binding. Try again in a second.") }
            return
        }

        runJob?.cancel()
        runJob = viewModelScope.launch {
            _ui.update { it.copy(state = ExecState.THINKING, errorMessage = null, currentConfirmation = "") }

            // 1. Capture current screen
            val executor = ZeroTouchAccessibilityService.get()
            val rootNode = executor?.currentRootNode()
            val screenDesc = screenAnalyzer.describeScreen(rootNode)

            // 2. Ask MiniMax
            val aiResult = repo.processCommand(text, screenDesc)
            val response = aiResult.getOrElse { t ->
                _ui.update {
                    it.copy(
                        state = ExecState.ERROR,
                        errorMessage = t.message ?: getApplication<Application>().getString(R.string.err_generic)
                    )
                }
                return@launch
            }
            _ui.update {
                it.copy(
                    lastResponse = response,
                    currentConfirmation = response.confirmation,
                    state = ExecState.EXECUTING
                )
            }

            // 3. Show overlay
            val app = getApplication<Application>()
            FloatingOverlayService.show(app)
            FloatingOverlayService.update(
                app,
                total = response.actions.size.coerceAtLeast(1),
                current = 1,
                desc = response.confirmation.ifBlank { "Starting…" }
            )

            // 4. Execute
            val result = actionEngine.execute(response)

            FloatingOverlayService.update(
                app,
                total = response.actions.size.coerceAtLeast(1),
                current = response.actions.size.coerceAtLeast(1),
                desc = if (result.ok) "✅ ${response.confirmation}" else "❌ ${result.summary}"
            )
            // Auto-hide after a few seconds — caller may also tap to dismiss.
            // We use a delayed hide via state observation in the UI.

            _ui.update {
                val newRecent = (listOf(
                    RecentCommand(text, result.ok, System.currentTimeMillis())
                ) + it.recent).take(10)
                it.copy(
                    state = if (result.ok) ExecState.DONE else ExecState.ERROR,
                    lastResult = result,
                    recent = newRecent
                )
            }
        }
    }

    fun clearError() {
        _ui.update { it.copy(errorMessage = null) }
    }

    fun hideOverlayNow() {
        FloatingOverlayService.hide(getApplication())
    }

    /**
     * Run an AI-driven quick command. Useful for chips like
     * "Take a screenshot" that need MiniMax reasoning.
     */
    fun runQuickAi(prompt: String) {
        _ui.update { it.copy(draft = prompt) }
        execute(prompt)
    }

    /**
     * Quick-action chips launch pre-baked commands. These are NOT going through
     * MiniMax — they shortcut directly into [ActionEngine] for instant feedback.
     */
    fun runQuickLaunch(packageName: String, label: String) {
        if (!_ui.value.accessibilityEnabled) {
            _ui.update { it.copy(errorMessage = getApplication<Application>().getString(R.string.err_no_a11y)) }
            return
        }
        val app = getApplication<Application>()
        try {
            val intent = app.packageManager.getLaunchIntentForPackage(packageName)
                ?: Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(packageName)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(intent)
            _ui.update {
                it.copy(
                    state = ExecState.DONE,
                    currentConfirmation = "Opening $label",
                    recent = (listOf(
                        RecentCommand("open $label", true, System.currentTimeMillis())
                    ) + it.recent).take(10)
                )
            }
        } catch (t: Throwable) {
            _ui.update { it.copy(state = ExecState.ERROR, errorMessage = "Couldn't open $label: ${t.message}") }
        }
    }
}
