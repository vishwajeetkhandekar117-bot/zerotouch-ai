package com.zerotouch.ai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zerotouch.ai.R
import com.zerotouch.ai.ui.ExecState
import com.zerotouch.ai.ui.RecentCommand
import com.zerotouch.ai.ui.UiState

@Composable
fun HomeScreen(
    state: UiState,
    onDraftChange: (String) -> Unit,
    onExecute: () -> Unit,
    onStop: () -> Unit,
    onOpenA11y: () -> Unit,
    onOpenOverlay: () -> Unit,
    onClearError: () -> Unit,
    onQuickAction: (packageName: String, label: String) -> Unit,
    onQuickAi: (prompt: String) -> Unit
) {
    val statusBarInset = WindowInsets.systemBars.asPaddingValues()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 20.dp)
    ) {
        // Top: title + status dot
        Spacer(Modifier.height(12.dp))
        HeaderRow(state = state, onOpenA11y = onOpenA11y, onOpenOverlay = onOpenOverlay)
        Spacer(Modifier.height(28.dp))

        // Hero: mic + status
        HeroMic(state = state)
        Spacer(Modifier.height(20.dp))

        // Confirmation / status line
        StatusLine(state = state)
        Spacer(Modifier.height(16.dp))

        // Quick actions
        QuickActions(onQuickAction = onQuickAction)
        Spacer(Modifier.height(16.dp))

        // Draft input + send/stop
        CommandInput(
            draft = state.draft,
            isExecuting = state.state == ExecState.EXECUTING || state.state == ExecState.THINKING,
            onDraftChange = onDraftChange,
            onExecute = onExecute,
            onStop = onStop
        )
        Spacer(Modifier.height(16.dp))

        AnimatedVisibility(visible = state.errorMessage != null) {
            ErrorBanner(state.errorMessage, onClearError)
        }
        AnimatedVisibility(visible = state.errorMessage != null) { Spacer(Modifier.height(8.dp)) }

        // Recent
        Text(
            "Recent",
            color = Color(0xFFB0B0B0),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        if (state.recent.isEmpty()) {
            Text(
                "Try: \"Open WhatsApp\", \"Take a screenshot\", \"Camera kholo\"",
                color = Color(0xFF707070),
                fontSize = 13.sp
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.recent, key = { it.timestampMs }) { recent ->
                    RecentRow(recent)
                }
            }
        }
    }
}

@Composable
private fun HeaderRow(state: UiState, onOpenA11y: () -> Unit, onOpenOverlay: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "ZeroTouch",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Speak or type to control your phone",
                color = Color(0xFFB0B0B0),
                fontSize = 12.sp
            )
        }
        StatusPill(
            label = if (state.accessibilityEnabled) "A11Y ✓" else "A11Y off",
            color = if (state.accessibilityEnabled) Color(0xFF4ADE80) else Color(0xFFFF5252),
            onClick = onOpenA11y
        )
        Spacer(Modifier.width(8.dp))
        StatusPill(
            label = if (state.overlayEnabled) "Overlay ✓" else "Overlay off",
            color = if (state.overlayEnabled) Color(0xFF4ADE80) else Color(0xFFFFB800),
            onClick = onOpenOverlay
        )
    }
}

@Composable
private fun StatusPill(label: String, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0xFF1A1A1A))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(6.dp))
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun HeroMic(state: UiState) {
    val infinite = rememberInfiniteTransition(label = "mic-pulse")
    val scale by infinite.animateFloat(
        initialValue = 1f,
        targetValue = if (state.state == ExecState.THINKING || state.state == ExecState.EXECUTING) 1.18f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size((110 * scale).dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF7C5CFF).copy(alpha = 0.4f),
                            Color.Black
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(78.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF7C5CFF), Color(0xFF00D4FF))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Mic,
                    contentDescription = "Voice command",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }
        }
    }
}

@Composable
private fun StatusLine(state: UiState) {
    val (text, color) = when (state.state) {
        ExecState.IDLE -> "Ready — type a command or pick a quick action" to Color(0xFFB0B0B0)
        ExecState.THINKING -> "Thinking…" to Color(0xFF00D4FF)
        ExecState.EXECUTING -> "Executing…" to Color(0xFFFFB800)
        ExecState.DONE -> state.currentConfirmation.ifBlank { "Done" } to Color(0xFF4ADE80)
        ExecState.ERROR -> (state.errorMessage ?: "Something failed") to Color(0xFFFF5252)
    }
    Text(
        text = text,
        color = color,
        fontSize = 14.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0A0A0A))
            .border(1.dp, Color(0xFF1A1A1A), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        maxLines = 3,
        overflow = TextOverflow.Ellipsis
    )
}

@Composable
private fun QuickActions(onQuickAction: (String, String) -> Unit) {
    val items = listOf(
        Triple("com.whatsapp", "WhatsApp", "💬"),
        Triple("com.google.android.youtube", "YouTube", "▶️"),
        Triple("com.android.camera", "Camera", "📷"),
        Triple("com.google.android.apps.maps", "Maps", "📍"),
        Triple("com.android.settings", "Settings", "⚙️"),
        Triple("com.instagram.android", "Instagram", "📸")
    )
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { (pkg, label, emoji) ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1A1A1A))
                    .border(1.dp, Color(0xFF242424), RoundedCornerShape(14.dp))
                    .clickable { onQuickAction(pkg, label) }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(emoji, fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun CommandInput(
    draft: String,
    isExecuting: Boolean,
    onDraftChange: (String) -> Unit,
    onExecute: () -> Unit,
    onStop: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0A0A0A))
            .border(1.dp, Color(0xFF242424), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = draft,
            onValueChange = onDraftChange,
            modifier = Modifier.weight(1f),
            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
            singleLine = true,
            cursorBrush = SolidColor(Color(0xFF7C5CFF)),
            decorationBox = { inner ->
                if (draft.isEmpty()) {
                    Text(
                        "Try: \"Open WhatsApp and message Mom\"",
                        color = Color(0xFF707070),
                        fontSize = 14.sp
                    )
                }
                inner()
            }
        )
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(
                    if (isExecuting) Color(0xFFFF5252)
                    else Brush.linearGradient(listOf(Color(0xFF7C5CFF), Color(0xFF00D4FF)))
                )
                .clickable {
                    if (isExecuting) onStop() else onExecute()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isExecuting) Icons.Filled.Stop else Icons.Filled.Send,
                contentDescription = if (isExecuting) "Stop" else "Send",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ErrorBanner(message: String?, onClear: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF2A0F12))
            .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .clickable(onClick = onClear),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("⚠️", fontSize = 14.sp)
        Spacer(Modifier.width(8.dp))
        Text(
            message ?: "Error",
            color = Color(0xFFFFB8B8),
            fontSize = 13.sp,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun RecentRow(recent: RecentCommand) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0A0A0A))
            .border(1.dp, Color(0xFF1A1A1A), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            if (recent.ok) "✓" else "✗",
            color = if (recent.ok) Color(0xFF4ADE80) else Color(0xFFFF5252),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.width(10.dp))
        Text(
            recent.text,
            color = Color(0xFFFAFAFA),
            fontSize = 13.sp,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
