package com.zerotouch.ai

import android.app.Application
import android.util.Log
import com.zerotouch.ai.util.SecurityUtils
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ZeroTouchApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Log.i(TAG, "ZeroTouch AI starting in DEBUG")
        }
        // Validate API key early so the user sees a friendly error.
        val key = BuildConfig.MINIMAX_API_KEY
        if (key.isBlank() || key == "YOUR_MINIMAX_KEY_HERE") {
            Log.w(TAG, "MINIMAX_API_KEY not set — set it in local.properties and rebuild")
        } else {
            Log.i(TAG, "API key loaded (length=${key.length})")
        }
        // Touch the security utils so the Android Keystore is initialised early.
        SecurityUtils.warmUp(this)
    }

    companion object {
        private const val TAG = "ZeroTouchApp"
    }
}
