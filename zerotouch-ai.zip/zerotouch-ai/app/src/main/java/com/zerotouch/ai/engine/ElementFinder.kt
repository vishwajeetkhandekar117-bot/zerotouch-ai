package com.zerotouch.ai.engine

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.zerotouch.ai.data.model.Bounds
import com.zerotouch.ai.data.model.ScreenElement

/**
 * Walks an AccessibilityNodeInfo tree and answers queries about it.
 *
 * All find* methods return the FIRST match, depth-first. Returns null if nothing matched.
 *
 * This class is intentionally NOT thread-safe. AccessibilityNodeInfo trees
 * must be accessed on the main thread (or you must recycle() nodes carefully).
 */
class ElementFinder {

    enum class FindBy {
        TEXT, CONTENT_DESC, RESOURCE_ID, CLASS;

        companion object {
            fun parse(raw: String?): FindBy? = when (raw?.lowercase()?.trim()) {
                "text" -> TEXT
                "content-desc", "content_description", "contentdescription" -> CONTENT_DESC
                "resource-id", "resource_id", "resourceid", "id" -> RESOURCE_ID
                "class", "classname", "class_name" -> CLASS
                else -> null
            }
        }
    }

    fun findElement(
        root: AccessibilityNodeInfo,
        by: FindBy,
        value: String,
        exact: Boolean = false
    ): ScreenElement? {
        val matcher: (AccessibilityNodeInfo) -> Boolean = when (by) {
            FindBy.TEXT -> { n -> n.text?.toString()?.let { if (exact) it == value else it.contains(value, true) } == true }
            FindBy.CONTENT_DESC -> { n -> n.contentDescription?.toString()?.let { if (exact) it == value else it.contains(value, true) } == true }
            FindBy.RESOURCE_ID -> { n -> n.viewIdResourceName?.let { if (exact) it == value else it.contains(value, true) } == true }
            FindBy.CLASS -> { n -> n.className?.toString()?.let { if (exact) it == value else it.contains(value, true) } == true }
        }
        return findFirst(root, matcher)?.toScreenElement()
    }

    /**
     * Find every element matching by+value. Returns leaves-first order.
     */
    fun findAll(
        root: AccessibilityNodeInfo,
        by: FindBy,
        value: String,
        exact: Boolean = false
    ): List<ScreenElement> {
        val out = mutableListOf<ScreenElement>()
        collectMatching(root, by, value, exact, out)
        return out
    }

    private fun collectMatching(
        node: AccessibilityNodeInfo,
        by: FindBy,
        value: String,
        exact: Boolean,
        out: MutableList<ScreenElement>
    ) {
        if (matches(node, by, value, exact)) out += node.toScreenElement()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectMatching(child, by, value, exact, out)
        }
    }

    private fun matches(node: AccessibilityNodeInfo, by: FindBy, value: String, exact: Boolean): Boolean {
        val candidate: String? = when (by) {
            FindBy.TEXT -> node.text?.toString()
            FindBy.CONTENT_DESC -> node.contentDescription?.toString()
            FindBy.RESOURCE_ID -> node.viewIdResourceName
            FindBy.CLASS -> node.className?.toString()
        }
        return if (exact) candidate == value
        else candidate?.contains(value, ignoreCase = true) == true
    }

    private fun findFirst(
        node: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val hit = findFirst(child, predicate)
            if (hit != null) return hit
        }
        return null
    }

    /**
     * Flatten the entire accessibility tree into ScreenElements.
     * Useful for giving the AI full screen context.
     */
    fun flatten(
        root: AccessibilityNodeInfo,
        includeNonInteractive: Boolean = false
    ): List<ScreenElement> {
        val out = mutableListOf<ScreenElement>()
        flattenInto(root, out, includeNonInteractive)
        return out
    }

    private fun flattenInto(
        node: AccessibilityNodeInfo,
        out: MutableList<ScreenElement>,
        includeNonInteractive: Boolean
    ) {
        val interactive = node.isClickable || node.isEditable || node.isScrollable ||
            !node.text.isNullOrBlank() || !node.contentDescription.isNullOrBlank()
        if (interactive || includeNonInteractive) {
            out += node.toScreenElement()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            flattenInto(child, out, includeNonInteractive)
        }
    }

    private fun AccessibilityNodeInfo.toScreenElement(): ScreenElement {
        val rect = Rect()
        getBoundsInScreen(rect)
        return ScreenElement(
            text = text?.toString(),
            contentDescription = contentDescription?.toString(),
            resourceId = viewIdResourceName,
            className = className?.toString(),
            bounds = Bounds(rect.left, rect.top, rect.right, rect.bottom),
            isClickable = isClickable,
            isEditable = isEditable,
            isScrollable = isScrollable,
            isEnabled = isEnabled
        )
    }
}
