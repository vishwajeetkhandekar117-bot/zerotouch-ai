package com.zerotouch.ai.data.remote

import com.zerotouch.ai.data.model.MiniMaxRequest
import com.zerotouch.ai.data.model.MiniMaxResponse
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

/**
 * MiniMax chat-completions-compatible endpoint.
 * Path is configurable via [retrofit2.Retrofit.Builder.baseUrl].
 */
interface MiniMaxApiService {

    @POST("chat/completions")
    suspend fun chat(
        @Header("Authorization") authorization: String,
        @Body request: MiniMaxRequest
    ): MiniMaxResponse
}
