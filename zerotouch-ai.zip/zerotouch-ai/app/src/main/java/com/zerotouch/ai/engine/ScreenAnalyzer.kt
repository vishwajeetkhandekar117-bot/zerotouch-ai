package com.zerotouch.ai.engine

import android.view.accessibility.AccessibilityNodeInfo
import com.zerotouch.ai.data.model.ScreenElement
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Builds a compact textual representation of the current screen.
 *
 * The output is what we ship to MiniMax so it knows what's on screen when
 * planning actions. We aggressively trim to stay under token budget.
 */
@Singleton
class ScreenAnalyzer @Inject constructor(
    private val elementFinder: ElementFinder
) {

    companion object {
        private const val MAX_ELEMENTS_IN_CONTEXT = 60
        private const val MIN_ELEMENT_AREA = 100   // px² — skip tiny noise
    }

    /**
     * Returns a multi-line description of all interactive + text-bearing elements.
     * If [rootNode] is null, returns a placeholder string.
     */
    fun describeScreen(rootNode: AccessibilityNodeInfo?, maxElements: Int = MAX_ELEMENTS_IN_CONTEXT): String {
        if (rootNode == null) {
            return "(screen content not available yet — try again after the target app has rendered)"
        }
        val all = elementFinder.flatten(rootNode, includeNonInteractive = false)
        val trimmed = all
            .filter { it.bounds.area >= MIN_ELEMENT_AREA }
            .filter { !it.text.isNullOrBlank() || !it.contentDescription.isNullOrBlank() || it.isClickable || it.isEditable }
            .take(maxElements)

        if (trimmed.isEmpty()) {
            return "(no interactive elements detected on screen)"
        }

        return buildString {
            appendLine("Current screen has ${trimmed.size} relevant elements:")
            trimmed.forEachIndexed { idx, el ->
                appendLine("${idx + 1}. ${el.describe()}")
            }
        }
    }

    /**
     * Same as [describeScreen] but also returns the structured elements in case
     * the caller needs them (e.g. for retry logic or local fallback).
     */
    fun analyze(rootNode: AccessibilityNodeInfo?): ScreenAnalysis {
        if (rootNode == null) return ScreenAnalysis.Empty
        val elements = elementFinder.flatten(rootNode)
        val description = describeScreen(rootNode)
        val packageName = rootNode.packageName?.toString()
        return ScreenAnalysis(
            packageName = packageName,
            description = description,
            elements = elements
        )
    }

    fun findElement(
        rootNode: AccessibilityNodeInfo?,
        by: ElementFinder.FindBy,
        value: String,
        exact: Boolean = false
    ): ScreenElement? {
        if (rootNode == null) return null
        return elementFinder.findElement(rootNode, by, value, exact)
    }
}

data class ScreenAnalysis(
    val packageName: String?,
    val description: String,
    val elements: List<ScreenElement>
) {
    companion object {
        val Empty = ScreenAnalysis(null, "(no screen)", emptyList())
    }
}
