package com.zerotouch.ai.data.model

import android.view.accessibility.AccessibilityNodeInfo

/** Pixel bounds as captured by AccessibilityNodeInfo. */
data class Bounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val area: Int get() = width * height

    fun contains(other: Bounds): Boolean =
        other.left >= left && other.top >= top &&
        other.right <= right && other.bottom <= bottom

    companion object {
        val EMPTY = Bounds(0, 0, 0, 0)

        fun fromAccessibilityNode(node: AccessibilityNodeInfo): Bounds {
            val rect = android.graphics.Rect()
            node.getBoundsInScreen(rect)
            return Bounds(rect.left, rect.top, rect.right, rect.bottom)
        }
    }
}

/** A simplified, serialisable screen element used both internally and as AI context. */
data class ScreenElement(
    val text: String?,
    val contentDescription: String?,
    val resourceId: String?,
    val className: String?,
    val bounds: Bounds,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean,
    val isEnabled: Boolean
) {
    /** Short human-readable label for the AI context. */
    fun describe(): String {
        val parts = mutableListOf<String>()
        if (isEditable) parts += "INPUT"
        else if (isClickable) parts += "BTN"
        else if (isScrollable) parts += "SCROLL"
        else parts += "TEXT"

        val label = text?.takeIf { it.isNotBlank() }
            ?: contentDescription?.takeIf { it.isNotBlank() }
            ?: resourceId?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            ?: className?.substringAfterLast('.')?.takeIf { it.isNotBlank() }
            ?: "?"

        return "[$parts] '$label' bounds=${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"
    }
}
