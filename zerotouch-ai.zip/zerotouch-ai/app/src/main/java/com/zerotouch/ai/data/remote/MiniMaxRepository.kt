package com.zerotouch.ai.data.remote

import android.util.Log
import com.google.gson.Gson
import com.zerotouch.ai.BuildConfig
import com.zerotouch.ai.data.model.AgentAction
import com.zerotouch.ai.data.model.AgentResponse
import com.zerotouch.ai.data.model.FunctionDef
import com.zerotouch.ai.data.model.Message
import com.zerotouch.ai.data.model.MiniMaxRequest
import com.zerotouch.ai.data.model.Tool
import com.zerotouch.ai.data.model.ToolParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Wraps the MiniMax API and returns an [AgentResponse].
 *
 * Two parse strategies:
 * 1) If the model uses function calling, we read the JSON arguments string.
 * 2) Otherwise we try to parse the assistant's content as JSON directly.
 *
 * The second strategy is more brittle but lets us support older models
 * that don't support tools.
 */
@Singleton
class MiniMaxRepository @Inject constructor(
    private val api: MiniMaxApiService,
    private val gson: Gson
) {

    private val systemPrompt: String = """
        You are ZeroTouch AI, a phone automation agent that controls an Android device
        through structured accessibility actions.

        You will be given:
        - The user's natural-language command (may be in Hindi, English, or mixed).
        - A textual description of the currently visible screen (interactive elements
          with text/content-desc and bounds).

        Your job is to produce a JSON plan of actions that achieves the user's goal.

        Rules:
        - ALWAYS prefer `find_and_tap` over raw `tap` coordinates when the target has
          visible text or content description.
        - Only use coordinates when no other identifier is reasonable.
        - After launching an app, insert a `wait` (1500–2500ms) to let it load.
        - If unsure, return an empty actions list and a `confirmation` explaining why.
        - Output STRICT JSON, no markdown fences, no prose outside JSON.
    """.trimIndent()

    /**
     * Build the `tools` array we expose to MiniMax so function calling can be used.
     * Single tool `plan_actions` whose arguments match [AgentResponse].
     */
    private val toolPlanActions: Tool by lazy {
        Tool(
            function = FunctionDef(
                name = "plan_actions",
                description = "Plan the sequence of accessibility actions needed to satisfy the user's command. Returns a strict JSON object with the same shape.",
                parameters = ToolParameters(
                    properties = mapOf(
                        "actions" to mapOf(
                            "type" to "array",
                            "description" to "List of actions to execute in order.",
                            "items" to mapOf(
                                "type" to "object",
                                "properties" to mapOf(
                                    "type" to mapOf("type" to "string", "enum" to listOf(
                                        "launch_app", "tap", "long_press", "swipe",
                                        "type_text", "press_back", "press_home",
                                        "press_recents", "scroll", "find_and_tap",
                                        "wait", "screenshot"
                                    )),
                                    "packageName" to mapOf("type" to "string"),
                                    "x" to mapOf("type" to "integer"),
                                    "y" to mapOf("type" to "integer"),
                                    "x2" to mapOf("type" to "integer"),
                                    "y2" to mapOf("type" to "integer"),
                                    "text" to mapOf("type" to "string"),
                                    "direction" to mapOf("type" to "string", "enum" to listOf("UP", "DOWN", "LEFT", "RIGHT")),
                                    "durationMs" to mapOf("type" to "integer"),
                                    "findBy" to mapOf("type" to "string", "enum" to listOf("text", "content-desc", "resource-id", "class")),
                                    "findValue" to mapOf("type" to "string"),
                                    "waitMs" to mapOf("type" to "integer")
                                )
                            )
                        ),
                        "confirmation" to mapOf("type" to "string", "description" to "One-line confirmation to show the user, in the same language as the user."),
                        "requiresConfirmation" to mapOf("type" to "boolean", "description" to "True if the user should confirm before executing (e.g. sending messages, posting)."),
                        "reasoning" to mapOf("type" to "string", "description" to "Optional internal reasoning shown to the user in the overlay.")
                    ),
                    required = listOf("actions", "confirmation")
                )
            )
        )
    }

    /**
     * Process the user command with optional screen context.
     * Always returns a result — failure is wrapped in Result.failure.
     */
    suspend fun processCommand(
        userCommand: String,
        screenContext: String? = null,
        useTools: Boolean = true
    ): Result<AgentResponse> = withContext(Dispatchers.IO) {
        try {
            val userContent = buildString {
                append("USER COMMAND:\n").append(userCommand).append("\n\n")
                if (!screenContext.isNullOrBlank()) {
                    append("CURRENT SCREEN:\n").append(screenContext).append("\n\n")
                } else {
                    append("CURRENT SCREEN: (not yet available)\n\n")
                }
                append("Respond with strict JSON only.")
            }

            val req = MiniMaxRequest(
                model = MiniMaxRequest.DEFAULT_MODEL,
                messages = listOf(
                    Message(role = "system", content = systemPrompt),
                    Message(role = "user", content = userContent)
                ),
                tools = if (useTools) listOf(toolPlanActions) else null,
                toolChoice = if (useTools) "auto" else null,
                temperature = 0.2,
                maxTokens = 1500
            )

            val apiKey = BuildConfig.MINIMAX_API_KEY
            if (apiKey.isBlank() || apiKey == "YOUR_MINIMAX_KEY_HERE") {
                return@withContext Result.failure(IllegalStateException("MINIMAX_API_KEY missing — set it in local.properties"))
            }

            val auth = "Bearer $apiKey"
            val response = api.chat(authorization = auth, request = req)
            val choice = response.choices.firstOrNull()
                ?: return@withContext Result.failure(IllegalStateException("MiniMax returned no choices"))

            val parsed = parseChoice(choice.message)
                ?: return@withContext Result.failure(IllegalStateException("MiniMax returned unparseable response"))

            Result.success(parsed)
        } catch (t: Throwable) {
            Log.e(TAG, "processCommand failed", t)
            Result.failure(t)
        }
    }

    /**
     * Try function-call arguments first, fall back to parsing content as JSON.
     * Returns null when neither works.
     */
    private fun parseChoice(message: Message): AgentResponse? {
        // 1) Function-call path
        val toolCall = message.toolCalls?.firstOrNull { it.function.name == "plan_actions" }
        if (toolCall != null) {
            return runCatching {
                gson.fromJson(toolCall.function.arguments, AgentResponse::class.java)
            }.getOrNull()
        }
        // 2) Content-as-JSON path
        val content = message.content?.trim().orEmpty()
        if (content.isBlank()) return null
        // Strip optional ```json fences
        val cleaned = stripCodeFences(content)
        val direct = runCatching { gson.fromJson(cleaned, AgentResponse::class.java) }.getOrNull()
        if (direct != null) return direct
        // 3) Last-ditch: build a no-op response with the content as confirmation
        return AgentResponse(
            actions = emptyList<AgentAction>(),
            confirmation = cleaned.take(280),
            reasoning = "Could not parse structured JSON, returned plain confirmation."
        )
    }

    private fun stripCodeFences(s: String): String {
        val regex = Regex("^```(?:json)?\\s*|\\s*```$", RegexOption.IGNORE_CASE)
        return s.replace(regex, "").trim()
    }

    companion object {
        private const val TAG = "MiniMaxRepo"
    }
}
