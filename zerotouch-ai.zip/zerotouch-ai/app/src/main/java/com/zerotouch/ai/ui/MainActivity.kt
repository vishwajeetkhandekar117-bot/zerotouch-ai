package com.zerotouch.ai.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import com.zerotouch.ai.R
import com.zerotouch.ai.service.ZeroTouchAccessibilityService
import com.zerotouch.ai.ui.screens.HomeScreen
import com.zerotouch.ai.ui.theme.ZeroTouchTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge / true AMOLED black
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            ZeroTouchTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    val ui by vm.ui.collectAsState()
                    HomeScreen(
                        state = ui,
                        onDraftChange = vm::onDraftChanged,
                        onExecute = { vm.execute() },
                        onStop = vm::stopExecution,
                        onOpenA11y = vm::openAccessibilitySettings,
                        onOpenOverlay = vm::openOverlaySettings,
                        onClearError = vm::clearError,
                        onQuickAction = { pkg, label -> vm.runQuickLaunch(pkg, label) },
                        onQuickAi = { prompt -> vm.runQuickAi(prompt) }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshPermissionsState(
            accessibilityEnabled = isAccessibilityEnabled(),
            overlayEnabled = Settings.canDrawOverlays(this)
        )
    }

    private fun isAccessibilityEnabled(): Boolean {
        val service = "$packageName/${ZeroTouchAccessibilityService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        if (enabled.isNullOrBlank()) return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            val component = splitter.next()
            if (component.equals(service, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    /**
     * Boot the overlay service permission check on Android 13+.
     */
    private fun requestPostNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1001)
            }
        }
    }
}
