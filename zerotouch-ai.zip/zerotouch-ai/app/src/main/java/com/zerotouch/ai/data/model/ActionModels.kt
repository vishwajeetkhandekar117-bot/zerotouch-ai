package com.zerotouch.ai.data.model

import com.google.gson.annotations.SerializedName

/**
 * Sealed class describing every action type the engine understands.
 * Sealed so we get exhaustiveness checks when pattern-matching.
 */
sealed class ActionType(val wire: String) {
    object LaunchApp : ActionType("launch_app")
    object Tap : ActionType("tap")
    object LongPress : ActionType("long_press")
    object Swipe : ActionType("swipe")
    object TypeText : ActionType("type_text")
    object PressBack : ActionType("press_back")
    object PressHome : ActionType("press_home")
    object PressRecents : ActionType("press_recents")
    object Scroll : ActionType("scroll")
    object FindAndTap : ActionType("find_and_tap")
    object Wait : ActionType("wait")
    object Screenshot : ActionType("screenshot")

    companion object {
        private val all = listOf(
            LaunchApp, Tap, LongPress, Swipe, TypeText,
            PressBack, PressHome, PressRecents, Scroll,
            FindAndTap, Wait, Screenshot
        )
        fun fromWire(value: String?): ActionType? =
            value?.let { v -> all.firstOrNull { it.wire == v.lowercase() } }
    }
}

/**
 * Wire format for an action returned by the AI.
 * All fields are optional — Gson populates only those present.
 */
data class AgentAction(
    @SerializedName("type") val type: String? = null,
    @SerializedName("packageName") val packageName: String? = null,
    @SerializedName("x") val x: Int? = null,
    @SerializedName("y") val y: Int? = null,
    @SerializedName("x2") val x2: Int? = null,
    @SerializedName("y2") val y2: Int? = null,
    @SerializedName("text") val text: String? = null,
    @SerializedName("direction") val direction: String? = null, // UP/DOWN/LEFT/RIGHT
    @SerializedName("durationMs") val durationMs: Long? = null,
    @SerializedName("findBy") val findBy: String? = null,        // text|content-desc|resource-id|class
    @SerializedName("findValue") val findValue: String? = null,
    @SerializedName("waitMs") val waitMs: Long? = null
) {
    val resolvedType: ActionType? get() = ActionType.fromWire(type)
}

/**
 * The full response shape the AI should return.
 * The MiniMaxRepository enforces this contract.
 */
data class AgentResponse(
    @SerializedName("actions") val actions: List<AgentAction> = emptyList(),
    @SerializedName("confirmation") val confirmation: String = "",
    @SerializedName("requiresConfirmation") val requiresConfirmation: Boolean = false,
    @SerializedName("reasoning") val reasoning: String? = null
)
