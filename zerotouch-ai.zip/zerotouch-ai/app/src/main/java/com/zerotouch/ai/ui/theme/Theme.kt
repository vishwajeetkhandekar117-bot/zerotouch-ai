package com.zerotouch.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Pure AMOLED palette
val AmoledBlack = Color(0xFF000000)
val SurfaceDark = Color(0xFF0A0A0A)
val SurfaceVariant = Color(0xFF1A1A1A)
val SurfaceHigh = Color(0xFF242424)

val AccentPrimary = Color(0xFF7C5CFF)
val AccentSecondary = Color(0xFF00D4FF)
val AccentTertiary = Color(0xFFFF4D8D)

val TextPrimary = Color(0xFFFAFAFA)
val TextSecondary = Color(0xFFB0B0B0)
val TextTertiary = Color(0xFF707070)

val StatusSuccess = Color(0xFF4ADE80)
val StatusWarning = Color(0xFFFFB800)
val StatusError = Color(0xFFFF5252)
val StatusInfo = Color(0xFF00D4FF)

private val ZtDarkColors = darkColorScheme(
    primary = AccentPrimary,
    onPrimary = TextPrimary,
    primaryContainer = SurfaceVariant,
    onPrimaryContainer = TextPrimary,
    secondary = AccentSecondary,
    onSecondary = AmoledBlack,
    secondaryContainer = SurfaceVariant,
    onSecondaryContainer = TextPrimary,
    tertiary = AccentTertiary,
    onTertiary = TextPrimary,
    background = AmoledBlack,
    onBackground = TextPrimary,
    surface = AmoledBlack,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = TextSecondary,
    error = StatusError,
    onError = TextPrimary
)

@Composable
fun ZeroTouchTheme(content: @Composable () -> Unit) {
    // We always force dark for AMOLED look, regardless of system setting.
    @Suppress("UNUSED_VARIABLE")
    val systemDark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = ZtDarkColors,
        typography = ZtTypography,
        content = content
    )
}
