package com.zerotouch.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.zerotouch.ai.engine.ActionExecutor
import com.zerotouch.ai.engine.ActionEngine
import com.zerotouch.ai.util.AccessibilityHelper
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * The crown jewel of ZeroTouch.
 *
 * Responsibilities:
 *   1) Hold a live AccessibilityNodeInfo root we can query.
 *   2) Translate high-level engine actions into real Android gestures
 *      (tap, long-press, swipe, back, home, recents) and key events.
 *   3) Implement [ActionExecutor] so the engine can call us without
 *      depending on a Service.
 *
 * Lifecycle:
 *   - Bound by the system once the user enables it from Settings.
 *   - Binds itself into [ActionEngine] on service connect.
 *   - Cleans up on destroy.
 */
@AndroidEntryPoint
class ZeroTouchAccessibilityService : AccessibilityService(), ActionExecutor {

    @Inject lateinit var actionEngine: ActionEngine

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var cachedRoot: AccessibilityNodeInfo? = null
    private var lastRefreshMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "Accessibility service connected")
        instance = this
        actionEngine.bindExecutor(this)
        // Initial root refresh
        cachedRoot = rootInActiveWindow
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.i(TAG, "Accessibility service unbound")
        instance = null
        actionEngine.bindExecutor(null)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        actionEngine.bindExecutor(null)
        scope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Throttle root refresh — events fire constantly.
        val now = System.currentTimeMillis()
        if (now - lastRefreshMs < ROOT_REFRESH_INTERVAL_MS) return
        lastRefreshMs = now
        cachedRoot = rootInActiveWindow
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    // ---------- ActionExecutor ----------

    override fun isReady(): Boolean = true   // we're literally the service

    override fun currentRootNode(): AccessibilityNodeInfo? {
        cachedRoot?.let { return it }
        val fresh = rootInActiveWindow
        cachedRoot = fresh
        return fresh
    }

    override fun tap(x: Int, y: Int): Boolean {
        return performGesture(buildGesture(x.toFloat(), y.toFloat(), null, 50L))
    }

    override fun longPress(x: Int, y: Int, durationMs: Long): Boolean {
        return performGesture(buildGesture(x.toFloat(), y.toFloat(), null, durationMs.coerceAtLeast(300L)))
    }

    override fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long): Boolean {
        return performGesture(buildGesture(x1.toFloat(), y1.toFloat(), floatArrayOf(x2.toFloat(), y2.toFloat()), durationMs))
    }

    override fun typeText(text: String): Boolean {
        // Strategy: find focused node, set text via ACTION_SET_TEXT.
        val root = currentRootNode() ?: return false
        val focused = AccessibilityHelper.findFocusedEditableNode(root)
            ?: AccessibilityHelper.findFirstEditableNode(root)
        if (focused == null) {
            Log.w(TAG, "typeText: no editable focused node")
            return false
        }
        val bundle = Bundle().apply {
            // CharSequence is the standard for ACTION_SET_TEXT
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        val ok = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
        if (ok) return true

        // Fallback: clear then set
        val clearBundle = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                ""
            )
        }
        focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, clearBundle)
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
    }

    override fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    override fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    override fun pressRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    override fun scroll(direction: String): Boolean {
        val root = currentRootNode() ?: return false
        val node = AccessibilityHelper.findFirstScrollableNode(root) ?: return false
        val action = when (direction.uppercase()) {
            "UP", "TOP" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            "DOWN", "BOTTOM" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            "LEFT" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) AccessibilityNodeInfo.ACTION_SCROLL_LEFT else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            "RIGHT" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) AccessibilityNodeInfo.ACTION_SCROLL_RIGHT else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else -> return false
        }
        return node.performAction(action)
    }

    // ---------- helpers ----------

    private fun buildGesture(
        x1: Float, y1: Float,
        endXY: FloatArray?,
        durationMs: Long
    ): GestureDescription {
        val path = Path()
        path.moveTo(x1, y1)
        if (endXY != null && endXY.size == 2) {
            path.lineTo(endXY[0], endXY[1])
        }
        return GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()
    }

    private fun performGesture(g: GestureDescription): Boolean {
        var accepted = false
        val latch = Object()
        @Suppress("DEPRECATION")
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                accepted = true
                synchronized(latch) { latch.notifyAll() }
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                accepted = false
                synchronized(latch) { latch.notifyAll() }
            }
        }
        val dispatched = dispatchGesture(g, cb, null)
        if (!dispatched) {
            Log.w(TAG, "dispatchGesture returned false — gesture rejected by system")
            return false
        }
        // Best-effort blocking wait. We avoid 5s+ blocks to keep the engine responsive.
        synchronized(latch) {
            try { latch.wait(GESTURE_WAIT_MS) } catch (_: InterruptedException) {}
        }
        return accepted
    }

    companion object {
        private const val TAG = "ZeroTouchA11y"
        private const val ROOT_REFRESH_INTERVAL_MS = 80L
        private const val GESTURE_WAIT_MS = 1500L

        @Volatile
        private var instance: ZeroTouchAccessibilityService? = null

        /** True if the system has the service bound. */
        fun isRunning(): Boolean = instance != null

        fun get(): ZeroTouchAccessibilityService? = instance
    }
}
