package com.zerotouch.ai.util

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Wraps the Jetpack EncryptedSharedPreferences so we can stash small secrets
 * (BYOK API keys, MCP tokens) without ever touching plaintext prefs.
 *
 * If the security library fails to initialise (some weird OEM keyboards
 * cause this), we fall back to ordinary prefs and log loudly.
 */
object SecurityUtils {

    private const val FILE_NAME = "zerotouch_secure_prefs"
    private const val TAG = "SecurityUtils"

    @Volatile private var cached: SharedPreferences? = null

    fun warmUp(context: Context) {
        try {
            cached = encryptedPrefs(context)
            Log.i(TAG, "Encrypted prefs initialised")
        } catch (t: Throwable) {
            Log.w(TAG, "Encrypted prefs unavailable, falling back to plain: ${t.message}")
            cached = context.getSharedPreferences("zerotouch_plain_prefs", Context.MODE_PRIVATE)
        }
    }

    fun prefs(context: Context): SharedPreferences {
        cached?.let { return it }
        return try {
            encryptedPrefs(context).also { cached = it }
        } catch (t: Throwable) {
            context.getSharedPreferences("zerotouch_plain_prefs", Context.MODE_PRIVATE).also { cached = it }
        }
    }

    fun saveString(context: Context, key: String, value: String) {
        prefs(context).edit().putString(key, value).apply()
    }

    fun readString(context: Context, key: String, default: String? = null): String? =
        prefs(context).getString(key, default)

    fun remove(context: Context, key: String) {
        prefs(context).edit().remove(key).apply()
    }

    private fun encryptedPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context, MasterKey.DEFAULT_MASTER_KEY_ALIAS)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
}
