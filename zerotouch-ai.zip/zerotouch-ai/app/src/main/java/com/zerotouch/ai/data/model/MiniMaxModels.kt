package com.zerotouch.ai.data.model

import com.google.gson.annotations.SerializedName

/**
 * Request payload for MiniMax /chat/completions endpoint.
 * Uses function-calling (tool use) to constrain the model to our action schema.
 */
data class MiniMaxRequest(
    @SerializedName("model") val model: String = DEFAULT_MODEL,
    @SerializedName("messages") val messages: List<Message>,
    @SerializedName("tools") val tools: List<Tool>? = null,
    @SerializedName("tool_choice") val toolChoice: String? = "auto",
    @SerializedName("max_tokens") val maxTokens: Int = 2048,
    @SerializedName("temperature") val temperature: Double = 0.2,
    @SerializedName("stream") val stream: Boolean = false
) {
    companion object {
        const val DEFAULT_MODEL = "MiniMax-Text-01"
    }
}

data class Message(
    @SerializedName("role") val role: String,            // system|user|assistant|tool
    @SerializedName("content") val content: String? = null,
    @SerializedName("tool_calls") val toolCalls: List<ToolCall>? = null,
    @SerializedName("tool_call_id") val toolCallId: String? = null
)

data class Tool(
    @SerializedName("type") val type: String = "function",
    @SerializedName("function") val function: FunctionDef
)

data class FunctionDef(
    @SerializedName("name") val name: String,
    @SerializedName("description") val description: String,
    @SerializedName("parameters") val parameters: ToolParameters
)

/**
 * JSON-schema-ish parameters object. We hand-build the Map so we don't depend
 * on a fancy schema library.
 */
data class ToolParameters(
    @SerializedName("type") val type: String = "object",
    @SerializedName("properties") val properties: Map<String, Map<String, Any>>,
    @SerializedName("required") val required: List<String> = emptyList()
)

data class ToolCall(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: String = "function",
    @SerializedName("function") val function: FunctionCall
)

data class FunctionCall(
    @SerializedName("name") val name: String,
    @SerializedName("arguments") val arguments: String  // JSON-encoded string
)

data class MiniMaxResponse(
    @SerializedName("id") val id: String? = null,
    @SerializedName("choices") val choices: List<Choice> = emptyList(),
    @SerializedName("usage") val usage: Usage? = null
)

data class Choice(
    @SerializedName("index") val index: Int = 0,
    @SerializedName("message") val message: Message,
    @SerializedName("finish_reason") val finishReason: String? = null
)

data class Usage(
    @SerializedName("prompt_tokens") val promptTokens: Int = 0,
    @SerializedName("completion_tokens") val completionTokens: Int = 0,
    @SerializedName("total_tokens") val totalTokens: Int = 0
)
