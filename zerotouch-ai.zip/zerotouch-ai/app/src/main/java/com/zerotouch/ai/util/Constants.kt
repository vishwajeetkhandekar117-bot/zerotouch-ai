package com.zerotouch.ai.util

/**
 * Hardcoded constants the rest of the codebase can rely on.
 */
object Constants {

    // Secure-prefs keys
    const val PREF_USER_API_KEY = "user_minimax_api_key"
    const val PREF_AI_MODE = "ai_mode"            // "cloud" | "byok"
    const val PREF_MCP_ENABLED = "mcp_enabled"
    const val PREF_MCP_PORT = "mcp_port"
    const val PREF_WAKE_WORD = "wake_word"
    const val PREF_WAKE_WORD_ENABLED = "wake_word_enabled"

    // Defaults
    const val DEFAULT_MCP_PORT = 7331
    const val DEFAULT_WAKE_WORD = "hey zero"

    // Common Android package names we use as quick actions
    object Packages {
        const val WHATSAPP = "com.whatsapp"
        const val YOUTUBE = "com.google.android.youtube"
        const val CAMERA = "com.android.camera"
        const val MAPS = "com.google.android.apps.maps"
        const val SETTINGS = "com.android.settings"
        const val INSTAGRAM = "com.instagram.android"
        const val CHROME = "com.android.chrome"
        const val PHONE = "com.android.dialer"
        const val MESSAGES = "com.google.android.apps.messaging"
    }

    // Timeouts (ms)
    const val MINI_MAX_TIMEOUT_MS = 30_000L
    const val GESTURE_DEFAULT_DURATION_MS = 50L
    const val LONG_PRESS_DEFAULT_DURATION_MS = 600L
}
