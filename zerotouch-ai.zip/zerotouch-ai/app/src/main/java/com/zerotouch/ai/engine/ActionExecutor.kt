package com.zerotouch.ai.engine

import android.view.accessibility.AccessibilityNodeInfo

/**
 * Abstraction over the Android accessibility layer so the ActionEngine
 * doesn't depend directly on AccessibilityService.
 *
 * Why: AccessibilityService is a Context-bound component and you can't
 * Hilt-inject a Service instance into a Singleton. So we route through
 * this interface, set once the service comes online.
 */
interface ActionExecutor {

    /** Performs a tap at absolute screen coords. Returns true on success. */
    fun tap(x: Int, y: Int): Boolean

    /** Long-press at absolute screen coords. */
    fun longPress(x: Int, y: Int, durationMs: Long = 600): Boolean

    /** Linear swipe between two points. */
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 300): Boolean

    /** Fills the currently focused input field. */
    fun typeText(text: String): Boolean

    /** Sends back key event. */
    fun pressBack(): Boolean

    /** Sends home key event. */
    fun pressHome(): Boolean

    /** Sends recents key event. */
    fun pressRecents(): Boolean

    /** Scrolls the screen in a direction (best-effort — uses first scrollable). */
    fun scroll(direction: String): Boolean

    /** Returns the current accessibility root node, or null if not ready. */
    fun currentRootNode(): AccessibilityNodeInfo?

    /** True when the service is connected and able to perform gestures. */
    fun isReady(): Boolean
}
