# ZeroTouch AI — Phase 1

A working Android foundation that lets users control their phone through natural-language commands powered by a large language model.

> **Status:** Phase 1 — project skeleton, accessibility service, action engine, MiniMax integration, and Compose UI. Phase 2 will add MCP server, voice pipeline, and macros.

---

## ✨ What works out of the box

- **Natural-language commands** sent to MiniMax with function calling — model returns a strict JSON plan of accessibility actions.
- **AccessibilityService** that performs real taps, long-presses, swipes, scroll, type-into-focused-field, back/home/recents.
- **ElementFinder** that locates UI nodes by `text`, `content-desc`, `resource-id`, or `class`.
- **ScreenAnalyzer** that ships a compact screen description to the model.
- **ActionEngine** with retry + per-step logging.
- **Floating overlay** showing live progress + emergency stop button.
- **Compose UI** with AMOLED black palette, mic pulse animation, quick-action chips, recent-commands list.
- **Hilt DI**, **Retrofit**, **OkHttp**, **Gson**, **EncryptedSharedPreferences** (Keystore-backed).

---

## 🛠️ Setup

### 1. Prerequisites

- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34 installed
- A real Android device (Android 10 / API 29 or newer) — emulators do **not** expose the gesture/take-screenshot API reliably

### 2. Get a MiniMax API key

1. Sign up at [platform.MiniMax.io](https://platform.MiniMax.io).
2. Create a key with chat + function-calling enabled.
3. Copy the key.

### 3. Configure local.properties

```bash
cp local.properties.template local.properties
```

Open `local.properties` and fill in:

```properties
sdk.dir=/Users/yourname/Library/Android/sdk
MINIMAX_API_KEY=sk-your-key-here
```

`local.properties` is gitignored — your key never leaves your machine.

### 4. Build & install

```bash
./gradlew :app:installDebug
```

### 5. Enable the Accessibility Service

1. Open the app.
2. Tap the **A11Y off** pill in the top right (or go to `Settings → Accessibility`).
3. Find **ZeroTouch AI Agent** and turn it on.
4. Accept the system warning dialog.

### 6. Grant Overlay permission (for the floating panel)

Tap the **Overlay off** pill → allow **Display over other apps**.

### 7. Try it

Type **"Open WhatsApp"** and tap send, or pick a quick action. The mic hero will pulse while MiniMax thinks, the floating overlay will show the live step, and the result will appear in **Recent**.

---

## 🧠 Architecture

```
ui (Compose)          ──> MainViewModel ──┐
                                         │
data.remote           ──────────────────> │ processCommand()
  └─ MiniMaxRepository                    │
                                         ▼
engine                 ┌────────────► ActionEngine
 ├─ ScreenAnalyzer      │                 │
 ├─ ElementFinder       │                 │ execute(AgentResponse)
 └─ ActionExecutor ◄────┘                 ▼
                              ZeroTouchAccessibilityService
                                         │
                                  FloatingOverlayService
```

- `ActionEngine` is the brain. It takes a parsed `AgentResponse` and walks through actions one by one.
- `ZeroTouchAccessibilityService` implements `ActionExecutor` and is the only thing that actually touches the screen.
- The service binds itself into the engine on connect and unbinds on destroy.
- The repository handles function-calling: a single tool `plan_actions` whose JSON arguments map 1:1 to `AgentResponse`.

---

## 🧪 Testing on device

After install:

| Test                                      | Expected                                                          |
|-------------------------------------------|-------------------------------------------------------------------|
| Open app                                  | Black AMOLED UI with mic pulse                                   |
| Tap **WhatsApp** chip                     | WhatsApp launches                                                |
| Type **"Open YouTube"** → Send            | YouTube launches via AI plan                                      |
| Type **"Take a screenshot"** → Send       | Confirmation shown — device screenshot shortcut is system-side   |
| Tap **A11Y off** pill                     | Accessibility settings open                                       |
| Run any command                           | Floating overlay appears top-right with progress + Stop button   |

---

## 🚧 Known limitations (Phase 1)

- **No voice/wake-word** — voice pipeline lands in Phase 2.
- **No MCP server** — WebSocket server ships in Phase 2.
- **No macros / Tasker integration** — Phase 2.
- **Single-language support for prompts** — works fine for Hindi/English but we only ship one system prompt.
- **No retry-with-AI-feedback** — current retry uses the same coordinates. We'll add screenshot-based re-plan in Phase 2.

---

## 📁 Project structure

```
zerotouch-ai/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/zerotouch/ai/
│       │   ├── ZeroTouchApp.kt
│       │   ├── data/
│       │   │   ├── model/        (ActionModels, MiniMaxModels, ScreenElement)
│       │   │   └── remote/       (MiniMaxApiService, MiniMaxRepository)
│       │   ├── engine/           (ActionEngine, ElementFinder, ScreenAnalyzer, ActionExecutor)
│       │   ├── service/          (ZeroTouchAccessibilityService, FloatingOverlayService)
│       │   ├── ui/               (MainActivity, MainViewModel, screens/HomeScreen, theme/)
│       │   ├── di/               (AppModule)
│       │   └── util/             (PermissionHelper, SecurityUtils, Constants, AccessibilityHelper)
│       └── res/                  (themes, colors, strings, layouts, drawables, xml/)
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── local.properties.template
```

---

## 📜 License

Personal / experimental — no license yet.
